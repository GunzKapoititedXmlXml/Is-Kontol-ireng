#!/usr/bin/env bash
# jalankan.sh - All in one: install deps, install cloudflared, start server + tunnel
# Support: Termux, Linux (apt/yum), macOS, WSL, Windows (Git Bash)

cd "$(dirname "$0")" || exit 1

TOKEN="eyJhIjoiY2FkNjFhM2UyYzk5Y2NiN2IwNTQ2MmU0MWY1N2JjNTYiLCJ0IjoiMzRlYzljNzEtYWNmZC00MzA1LTlkNjEtMzMxZGFiMGRiNTBiIiwicyI6Ik5XSXhaVFJqTlRZdFpXVm1PQzAwTnpZNExXRTBORGt0TVdFNU5UQTFPREprWVdNeSJ9"

# ============================================
# DETEKSI PLATFORM
# ============================================
detect_platform() {
    OS_TYPE="unknown"
    ARCH=$(uname -m 2>/dev/null || echo "unknown")

    # Termux
    if [ -n "$PREFIX" ] && echo "$PREFIX" | grep -q "com.termux"; then
        OS_TYPE="termux"
        return
    fi
    if [ -d "/data/data/com.termux/files/usr" ]; then
        OS_TYPE="termux"
        return
    fi

    UNAME_S=$(uname -s 2>/dev/null || echo "unknown")
    case "$UNAME_S" in
        Linux*)
            if grep -qi microsoft /proc/version 2>/dev/null; then
                OS_TYPE="wsl"
            else
                OS_TYPE="linux"
            fi
            ;;
        Darwin*) OS_TYPE="macos" ;;
        MINGW*|MSYS*|CYGWIN*) OS_TYPE="windows" ;;
        *) OS_TYPE="unknown" ;;
    esac
}

# ============================================
# NAMA BINARY CLOUDFLARED SESUAI OS+ARCH
# ============================================
get_cloudflared_binary() {
    case "$OS_TYPE" in
        termux|linux|wsl)
            case "$ARCH" in
                aarch64|arm64) echo "cloudflared-linux-arm64" ;;
                armv7l|armv6l|arm) echo "cloudflared-linux-arm" ;;
                x86_64|amd64) echo "cloudflared-linux-amd64" ;;
                *) echo "" ;;
            esac
            ;;
        macos)
            case "$ARCH" in
                arm64) echo "cloudflared-darwin-arm64.tgz" ;;
                x86_64) echo "cloudflared-darwin-amd64.tgz" ;;
                *) echo "" ;;
            esac
            ;;
        windows)
            case "$ARCH" in
                x86_64|amd64) echo "cloudflared-windows-amd64.exe" ;;
                aarch64|arm64) echo "cloudflared-windows-arm64.exe" ;;
                *) echo "" ;;
            esac
            ;;
        *) echo "" ;;
    esac
}

# ============================================
# FOLDER TUJUAN INSTALL CLOUDFLARED
# ============================================
get_bin_dir() {
    case "$OS_TYPE" in
        termux)
            echo "${PREFIX}/bin"
            ;;
        *)
            # Linux/macOS/WSL/Windows: pakai ./bin lokal (portable)
            echo "$(pwd)/bin"
            ;;
    esac
}

# ============================================
# MODE
# ============================================
CHECK_ONLY=0
if [ "$1" = "--check-only" ]; then
    CHECK_ONLY=1
fi

detect_platform

if [ "$CHECK_ONLY" = "0" ]; then
    echo "=========================================="
    echo " MARCHANT ID - Auto Setup & Run"
    echo "=========================================="
    echo " Platform: $OS_TYPE ($ARCH)"
    echo "=========================================="
else
    echo "[setup] Platform: $OS_TYPE ($ARCH)"
fi

# ============================================
# 1. CEK NODE.JS
# ============================================
if ! command -v node >/dev/null 2>&1; then
    echo "[!] Node.js tidak ditemukan. Install dulu:"
    case "$OS_TYPE" in
        termux)  echo "    pkg install nodejs-lts" ;;
        linux|wsl) echo "    sudo apt install nodejs npm   # Debian/Ubuntu" ;;
        macos)   echo "    brew install node" ;;
        windows) echo "    Download dari https://nodejs.org" ;;
    esac
    exit 1
fi
if [ "$CHECK_ONLY" = "0" ]; then
    echo "[OK] Node.js: $(node --version)"
fi

# ============================================
# 2. PILIH PACKAGE MANAGER
# ============================================
if command -v npm >/dev/null 2>&1; then
    PM="npm"
elif command -v yarn >/dev/null 2>&1; then
    PM="yarn"
else
    echo "[!] npm/yarn tidak ada."
    exit 1
fi
if [ "$CHECK_ONLY" = "0" ]; then
    echo "[OK] Package manager: $PM"
fi

# ============================================
# 3. INSTALL DEPENDENCIES
# ============================================
if [ "$CHECK_ONLY" = "0" ]; then
    if [ ! -d "node_modules" ] || [ ! -f "node_modules/express/package.json" ]; then
        echo ""
        echo "[1/3] Install dependencies..."
        $PM install --ignore-scripts
    else
        echo "[1/3] Dependencies sudah ada, skip install."
    fi
fi

# ============================================
# 4. CEK / INSTALL CLOUDFLARED
# ============================================
if [ "$CHECK_ONLY" = "0" ]; then
    echo ""
    echo "[2/3] Cek cloudflared..."
fi

if command -v cloudflared >/dev/null 2>&1; then
    if [ "$CHECK_ONLY" = "0" ]; then
        echo "      cloudflared sudah ada: $(cloudflared --version 2>&1 | head -n1)"
    else
        echo "[setup] cloudflared OK"
    fi
else
    if [ "$CHECK_ONLY" = "0" ]; then
        echo "      cloudflared belum ada, install otomatis..."
    fi

    INSTALLED=0

    # --- Termux: coba pkg dulu
    if [ "$OS_TYPE" = "termux" ] && command -v pkg >/dev/null 2>&1; then
        if [ "$CHECK_ONLY" = "0" ]; then
            echo "      Coba: pkg install cloudflared"
        fi
        pkg install -y cloudflared >/dev/null 2>&1 || true
        command -v cloudflared >/dev/null 2>&1 && INSTALLED=1
    fi

    # --- Linux/WSL: coba apt kalau ada sudo
    if [ "$INSTALLED" = "0" ] && { [ "$OS_TYPE" = "linux" ] || [ "$OS_TYPE" = "wsl" ]; }; then
        if command -v apt-get >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
            if [ "$CHECK_ONLY" = "0" ]; then
                echo "      Coba: sudo apt install cloudflared (via repo cloudflare)"
            fi
            (
                sudo mkdir -p --mode=0755 /usr/share/keyrings 2>/dev/null
                curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
                  | sudo tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null 2>&1
                echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main" \
                  | sudo tee /etc/apt/sources.list.d/cloudflared.list >/dev/null 2>&1
                sudo apt-get update -y >/dev/null 2>&1
                sudo apt-get install -y cloudflared >/dev/null 2>&1
            ) || true
            command -v cloudflared >/dev/null 2>&1 && INSTALLED=1
        fi
    fi

    # --- Fallback: download binary
    if [ "$INSTALLED" = "0" ]; then
        BIN_NAME=$(get_cloudflared_binary)
        if [ -z "$BIN_NAME" ]; then
            echo "[!] Arsitektur $ARCH tidak didukung otomatis."
            echo "    Download manual: https://github.com/cloudflare/cloudflared/releases"
            exit 1
        fi

        if [ "$CHECK_ONLY" = "0" ]; then
            echo "      Download binary: $BIN_NAME"
        fi

        BIN_DIR=$(get_bin_dir)
        mkdir -p "$BIN_DIR" || true

        # Nama file tujuan
        if [ "$OS_TYPE" = "windows" ]; then
            TARGET="$BIN_DIR/cloudflared.exe"
        else
            TARGET="$BIN_DIR/cloudflared"
        fi

        URL="https://github.com/cloudflare/cloudflared/releases/latest/download/$BIN_NAME"

        # Download
        if command -v curl >/dev/null 2>&1; then
            curl -sL -o "$TARGET" "$URL" || true
        elif command -v wget >/dev/null 2>&1; then
            wget -q -O "$TARGET" "$URL" || true
        fi

        # macOS: extract .tgz
        if [ "$OS_TYPE" = "macos" ] && echo "$BIN_NAME" | grep -q ".tgz"; then
            if [ -f "$TARGET" ]; then
                tar -xzf "$TARGET" -C "$BIN_DIR" 2>/dev/null || true
                rm -f "$TARGET"
                # Hasil extract biasanya bernama "cloudflared"
                [ -f "$BIN_DIR/cloudflared" ] || true
            fi
        fi

        # chmod +x (kecuali windows)
        if [ "$OS_TYPE" != "windows" ] && [ -f "$BIN_DIR/cloudflared" ]; then
            chmod +x "$BIN_DIR/cloudflared"
        fi

        # Tambahkan ke PATH untuk sesi ini
        export PATH="$BIN_DIR:$PATH"
        hash -r 2>/dev/null || true

        command -v cloudflared >/dev/null 2>&1 && INSTALLED=1
    fi

    # Verifikasi akhir
    if ! command -v cloudflared >/dev/null 2>&1; then
        if [ "$CHECK_ONLY" = "0" ]; then
            echo "[!] Gagal install cloudflared otomatis."
            echo "    Install manual sesuai OS:"
            case "$OS_TYPE" in
                termux)  echo "    pkg install cloudflared" ;;
                linux|wsl) echo "    sudo apt install cloudflared" ;;
                macos)   echo "    brew install cloudflared" ;;
                windows) echo "    winget install Cloudflare.cloudflared" ;;
            esac
            exit 1
        else
            echo "[setup] WARN cloudflared belum ada, install manual."
            exit 0
        fi
    fi

    if [ "$CHECK_ONLY" = "0" ]; then
        echo "      cloudflared OK: $(cloudflared --version 2>&1 | head -n1)"
    fi
fi

# Selesai kalau check-only
if [ "$CHECK_ONLY" = "1" ]; then
    echo "[setup] Environment siap. Jalankan: yarn start"
    exit 0
fi

# ============================================
# 5. MATIKAN PROSES LAMA
# ============================================
echo ""
echo "[3/3] Menjalankan server & tunnel..."

# Kill lintas platform
if command -v pkill >/dev/null 2>&1; then
    pkill -f "node server.js" 2>/dev/null || true
    pkill -f "cloudflared tunnel run" 2>/dev/null || true
elif command -v taskkill >/dev/null 2>&1; then
    # Windows
    taskkill //F //IM node.exe >/dev/null 2>&1 || true
    taskkill //F //IM cloudflared.exe >/dev/null 2>&1 || true
fi
sleep 1

# ============================================
# 6. JALANKAN SERVER
# ============================================
node server.js > server.log 2>&1 &
SERVER_PID=$!
sleep 2

if ! kill -0 $SERVER_PID 2>/dev/null; then
    echo "[!] Server gagal start. Cek server.log:"
    tail -20 server.log 2>/dev/null
    exit 1
fi
echo "      Server OK (PID: $SERVER_PID)"
echo "      Log: tail -f server.log"

# ============================================
# 7. JALANKAN TUNNEL
# ============================================
cloudflared tunnel run --token "$TOKEN" > tunnel.log 2>&1 &
TUNNEL_PID=$!
sleep 3

if ! kill -0 $TUNNEL_PID 2>/dev/null; then
    echo "[!] Tunnel gagal start. Cek tunnel.log:"
    tail -20 tunnel.log 2>/dev/null
    kill $SERVER_PID 2>/dev/null
    exit 1
fi
echo "      Tunnel OK (PID: $TUNNEL_PID)"
echo "      Log: tail -f tunnel.log"

# ============================================
# 8. INFO
# ============================================
echo ""
echo "=========================================="
echo " BERJALAN"
echo " Platform: $OS_TYPE ($ARCH)"
echo " Local   : http://localhost:8000"
echo " Public  : https://marchant-id.xonepanel.qzz.io"
echo "=========================================="
echo " Tekan Ctrl+C untuk stop"
echo "=========================================="

# ============================================
# 9. TRAP CTRL+C
# ============================================
cleanup() {
    echo ""
    echo "Menghentikan..."
    kill $SERVER_PID $TUNNEL_PID 2>/dev/null || true
    exit 0
}
trap cleanup INT TERM

wait