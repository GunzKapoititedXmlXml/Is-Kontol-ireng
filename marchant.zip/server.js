// ============================================================
// server.js — MARCHANT ID (BuatQris + Supabase, 1 Tabel)
// Load semua data dari Supabase saat startup → CACHE
// Setiap write: update Supabase + CACHE
// ============================================================
const express      = require('express');
const path         = require('path');
const fs           = require('fs');
const bcrypt       = require('bcryptjs');
const jwt          = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const crypto       = require('crypto');
const qs           = require('querystring');
const FormData     = require('form-data');
const axios        = require('axios');
const { createClient } = require('@supabase/supabase-js');

// ============================================================
// KONFIG
// ============================================================
const CONFIG = {
    PORT: 8000,
    JWT_SECRET: 'oceanPaymentSecretKey2024',

    SUPABASE_URL: 'https://ousvifkyifrulfhiklso.supabase.co',
    SUPABASE_KEY: 'sb_publishable_uWMARDJoJ8O5OwXJVhK-VQ_RU66Sg_2',

    TELEGRAM_BOT_TOKEN: '8846520333:AAEi5LoRgBZvuzQDgtI_fdbtxm0GMtecNtA',
    TELEGRAM_GROUP_USERNAME: '@marchantid',
    TELEGRAM_FALLBACK_CHAT_ID: '-1003958656799',
    TELEGRAM_BUTTONS: {
        website: 'https://marchant-id.xonepanel.qzz.io',
        group:   'https://t.me/marchantid',
        bot:     ''
    },

    BUATQRIS: {
        ACCOUNT_ID:     'user_6ab810a3826029.59197976',
        SECRET_TOKEN:   'sk_live_184b9c01cfa7d83f298e19c6b28255a8fbd1e327fbc7d60d5836d8eeba0a3d0f',
        SIGNING_SECRET: 'belum-diisi',
        BASE_URL:       'https://api.buatqris.site'
    },

    APP_BASE_URL: 'https://marchant-id.xonepanel.qzz.io',
    ALLOWED_ORIGINS: [
        'http://localhost:8000',
        'http://127.0.0.1:8000',
        'https://marchant-id.xonepanel.qzz.io',
        'https://www.marchant-id.xonepanel.qzz.io'
    ],

    WITHDRAW_MIN: 20000,
    WITHDRAW_MAX: 10000000,
    WITHDRAW_METHODS: [
        { id: 'dana',  name: 'DANA',  type: 'ewallet', placeholder: 'Nomor DANA' },
        { id: 'gopay', name: 'GoPay', type: 'ewallet', placeholder: 'Nomor GoPay' },
        { id: 'ovo',   name: 'OVO',   type: 'ewallet', placeholder: 'Nomor OVO' }
    ]
};

const TOPUP_PACKAGES = [
    { id: '1k',   nominal: 1000,   label: 'Rp 1.000' },
    { id: '5k',   nominal: 5000,   label: 'Rp 5.000' },
    { id: '10k',  nominal: 10000,  label: 'Rp 10.000' },
    { id: '15k',  nominal: 15000,  label: 'Rp 15.000' },
    { id: '20k',  nominal: 20000,  label: 'Rp 20.000' },
    { id: '30k',  nominal: 30000,  label: 'Rp 30.000' },
    { id: '40k',  nominal: 40000,  label: 'Rp 40.000' },
    { id: '50k',  nominal: 50000,  label: 'Rp 50.000' },
    { id: '75k',  nominal: 75000,  label: 'Rp 75.000' },
    { id: '100k', nominal: 100000, label: 'Rp 100.000' },
    { id: '150k', nominal: 150000, label: 'Rp 150.000' },
    { id: '200k', nominal: 200000, label: 'Rp 200.000' }
];

// ============================================================
// SUPABASE
// ============================================================
const supabase = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false }
});

// ============================================================
// CACHE (di-load dari Supabase saat startup)
// ============================================================
const CACHE = {
    users:    [],   // [{ id, username, email, password, balance, created_at }]
    apiKeys:  [],   // [{ id, username, key, name, is_active, ... }]
    qris:     [],   // [{ id, username, transaction_id, amount, status, ... }]
    withdraws: [],  // [{ id, username, amount, method, status, ... }]
    webhooks: [],   // [{ id, event, delivery }]
    legacy:   [],   // [{ id, username, type, amount, ... }]
    loadedAt: null
};

// ============================================================
// LOAD DARI SUPABASE
// ============================================================
async function loadFromSupabase() {
    console.log('[STARTUP] Loading data dari Supabase...');
    try {
        const { data, error } = await supabase.from('app_data').select('*');
        if (error) {
            console.error('[STARTUP] ❌ Gagal load:', error.message);
            return false;
        }

        CACHE.users = [];
        CACHE.apiKeys = [];
        CACHE.qris = [];
        CACHE.withdraws = [];
        CACHE.webhooks = [];
        CACHE.legacy = [];

        for (const row of (data || [])) {
            const entry = {
                id: row.id,
                username: row.username,
                created_at: row.created_at,
                updated_at: row.updated_at,
                ...(row.data || {})
            };
            switch (row.type) {
                case 'user':     CACHE.users.push(entry); break;
                case 'api_key':  CACHE.apiKeys.push(entry); break;
                case 'qris':     CACHE.qris.push(entry); break;
                case 'withdraw': CACHE.withdraws.push(entry); break;
                case 'webhook':  CACHE.webhooks.push(entry); break;
                case 'legacy':   CACHE.legacy.push(entry); break;
            }
        }

        CACHE.loadedAt = new Date().toISOString();
        console.log(`[STARTUP] ✅ Loaded: ${CACHE.users.length} users, ${CACHE.apiKeys.length} api_keys, ${CACHE.qris.length} qris, ${CACHE.withdraws.length} withdraws, ${CACHE.webhooks.length} webhooks`);
        return true;
    } catch (e) {
        console.error('[STARTUP] ❌ Error:', e.message);
        return false;
    }
}

// Sync ringan tiap 5 menit (opsional, biar tidak stale kalau ada instance lain)
function startPeriodicSync() {
    setInterval(async () => {
        console.log('[SYNC] Refresh cache dari Supabase...');
        await loadFromSupabase();
    }, 5 * 60 * 1000);
}

// ============================================================
// DB HELPERS (pakai CACHE + tulis ke Supabase)
// ============================================================
function cacheBucket(type) {
    switch (type) {
        case 'user':     return CACHE.users;
        case 'api_key':  return CACHE.apiKeys;
        case 'qris':     return CACHE.qris;
        case 'withdraw': return CACHE.withdraws;
        case 'webhook':  return CACHE.webhooks;
        case 'legacy':   return CACHE.legacy;
        default:         return null;
    }
}

async function dbInsert({ id, type, username = null, data }) {
    const now = new Date().toISOString();
    const { error } = await supabase.from('app_data').insert({
        id, type, username, data, created_at: now, updated_at: now
    });
    if (error) throw error;

    const bucket = cacheBucket(type);
    if (bucket) {
        bucket.push({ id, username, created_at: now, updated_at: now, ...data });
    }
}

async function dbUpdateData(type, id, patchData) {
    const now = new Date().toISOString();
    const { error } = await supabase.from('app_data')
        .update({ data: patchData, updated_at: now })
        .eq('type', type).eq('id', id);
    if (error) throw error;

    const bucket = cacheBucket(type);
    if (bucket) {
        const idx = bucket.findIndex(r => r.id === id);
        if (idx >= 0) {
            const prev = bucket[idx];
            bucket[idx] = {
                id: prev.id,
                username: prev.username,
                created_at: prev.created_at,
                updated_at: now,
                ...patchData
            };
        }
    }
}

async function dbPatchJson(type, id, patch) {
    const row = dbGet(type, id);
    if (!row) return null;
    // pisahkan field internal
    const { id: _i, username: _u, created_at: _c, updated_at: _u2, ...jsonData } = row;
    const merged = { ...jsonData, ...patch };
    await dbUpdateData(type, id, merged);
    return merged;
}

function dbGet(type, id) {
    const bucket = cacheBucket(type);
    if (!bucket) return null;
    return bucket.find(r => r.id === id) || null;
}

function dbListByUser(type, username) {
    const bucket = cacheBucket(type);
    if (!bucket) return [];
    return bucket
        .filter(r => r.username === username)
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
}

// ============================================================
// USER
// ============================================================
function getUserByUsername(username) {
    return CACHE.users.find(u => u.username === username) || null;
}

// Refresh satu user dari Supabase (dipakai setelah RPC credit_balance)
async function refreshUserFromSupabase(username) {
    const { data, error } = await supabase
        .from('app_data').select('*')
        .eq('type', 'user').eq('id', username).maybeSingle();
    if (error || !data) return null;

    const entry = {
        id: data.id, username: data.username,
        created_at: data.created_at, updated_at: data.updated_at,
        ...(data.data || {})
    };
    const idx = CACHE.users.findIndex(u => u.username === username);
    if (idx >= 0) CACHE.users[idx] = entry;
    else CACHE.users.push(entry);
    return entry;
}

// ============================================================
// HELPERS
// ============================================================
const rupiah = (n) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');
const nowWIB = () => new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

// ============================================================
// TELEGRAM
// ============================================================
const TELEGRAM_API = `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}`;
const IMAGES_DIR = path.join(__dirname, 'images');
let _cachedGroupChatId = null;

async function autoDetectChatIdFromUpdates() {
    try {
        const res = await axios.get(`${TELEGRAM_API}/getUpdates`, { timeout: 10000 });
        if (!res.data?.ok || !Array.isArray(res.data.result)) return null;
        const chats = new Map();
        for (const upd of res.data.result) {
            const chat = upd.message?.chat || upd.channel_post?.chat
                || upd.my_chat_member?.chat || upd.edited_message?.chat;
            if (chat && ['group', 'supergroup', 'channel'].includes(chat.type)) chats.set(chat.id, chat);
        }
        if (chats.size === 0) return null;
        const arr = [...chats.values()];
        return arr[arr.length - 1].id;
    } catch { return null; }
}

async function resolveGroupChatId() {
    if (_cachedGroupChatId) return _cachedGroupChatId;
    if (CONFIG.TELEGRAM_GROUP_USERNAME?.startsWith('@')) {
        try {
            const res = await axios.get(`${TELEGRAM_API}/getChat`, {
                params: { chat_id: CONFIG.TELEGRAM_GROUP_USERNAME }, timeout: 10000
            });
            if (res.data?.ok && res.data.result?.id) {
                _cachedGroupChatId = res.data.result.id;
                return _cachedGroupChatId;
            }
        } catch (e) { console.warn('[TELEGRAM] getChat:', e.message); }
    }
    const detected = await autoDetectChatIdFromUpdates();
    if (detected) { _cachedGroupChatId = detected; return _cachedGroupChatId; }
    if (CONFIG.TELEGRAM_FALLBACK_CHAT_ID) {
        _cachedGroupChatId = CONFIG.TELEGRAM_FALLBACK_CHAT_ID;
        return _cachedGroupChatId;
    }
    return null;
}

function findImage(imageName) {
    if (!imageName) return null;
    const base = path.parse(imageName).name;
    for (const ext of ['.jpg', '.jpeg', '.png', '.webp']) {
        const p = path.join(IMAGES_DIR, base + ext);
        if (fs.existsSync(p)) return p;
    }
    return null;
}

function buildInlineKeyboard() {
    const b = CONFIG.TELEGRAM_BUTTONS;
    const row1 = [];
    if (b.website) row1.push({ text: 'Website', url: b.website });
    if (b.group)   row1.push({ text: 'Link Grup', url: b.group });
    const row2 = [];
    if (b.bot)     row2.push({ text: 'Notifikasi Bot Private', url: b.bot });
    const rows = [];
    if (row1.length) rows.push(row1);
    if (row2.length) rows.push(row2);
    return { inline_keyboard: rows };
}

async function sendTelegramPhoto(imageName, caption) {
    try {
        const chatId = await resolveGroupChatId();
        if (!chatId) return false;
        const imagePath = findImage(imageName);
        const replyMarkup = buildInlineKeyboard();

        if (imagePath) {
            try {
                const form = new FormData();
                form.append('chat_id', String(chatId));
                form.append('caption', caption);
                form.append('parse_mode', 'HTML');
                form.append('reply_markup', JSON.stringify(replyMarkup));
                form.append('photo', fs.createReadStream(imagePath));
                await axios.post(`${TELEGRAM_API}/sendPhoto`, form, {
                    headers: form.getHeaders(), timeout: 30000,
                    maxContentLength: Infinity, maxBodyLength: Infinity
                });
                return true;
            } catch (e) {
                console.error(`[TELEGRAM] sendPhoto GAGAL: ${e.response?.data?.description || e.message}`);
            }
        }

        try {
            await axios.post(`${TELEGRAM_API}/sendMessage`, {
                chat_id: chatId, text: caption, parse_mode: 'HTML',
                disable_web_page_preview: true, reply_markup: replyMarkup
            }, { timeout: 15000 });
            return true;
        } catch (e) {
            const status = e.response?.status;
            console.error(`[TELEGRAM] sendMessage GAGAL [${status}]: ${e.response?.data?.description || e.message}`);
            if (status === 403 || status === 400) {
                _cachedGroupChatId = null;
                const alt = await autoDetectChatIdFromUpdates();
                if (alt && alt !== chatId) {
                    try {
                        await axios.post(`${TELEGRAM_API}/sendMessage`, {
                            chat_id: alt, text: caption, parse_mode: 'HTML',
                            disable_web_page_preview: true, reply_markup: replyMarkup
                        }, { timeout: 15000 });
                        _cachedGroupChatId = alt;
                        return true;
                    } catch (_) {}
                }
            }
            return false;
        }
    } catch (err) {
        console.error('[TELEGRAM]', err.message);
        return false;
    }
}

async function debugTelegramInfo() {
    console.log('\n[TELEGRAM] ===== DEBUG =====');
    try {
        const me = await axios.get(`${TELEGRAM_API}/getMe`, { timeout: 10000 });
        console.log(`[TELEGRAM] Bot: @${me.data?.result?.username}`);
    } catch (e) {
        console.error('[TELEGRAM] getMe GAGAL:', e.response?.data?.description || e.message);
    }
    console.log('[TELEGRAM] ================\n');
}

// ============================================================
// BUATQRIS SERVICE
// ============================================================
class BuatQrisService {
    constructor(cfg = CONFIG.BUATQRIS) {
        this.cfg = cfg;
        this.client = axios.create({
            baseURL: cfg.BASE_URL, timeout: 15000,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            validateStatus: () => true
        });
    }
    async _call(action, params = {}) {
        const body = { action, account_id: this.cfg.ACCOUNT_ID, secret_token: this.cfg.SECRET_TOKEN, ...params };
        const res = await this.client.post('/', qs.stringify(body));
        return { httpStatus: res.status, body: res.data };
    }
    async createQris({ amount, description, qris_method, fee_by, test, callback_url }) {
        const params = { amount };
        if (description) params.description = String(description).slice(0, 100);
        if (qris_method) params.qris_method = qris_method;
        if (fee_by) params.fee_by = fee_by;
        if (callback_url) params.callback_url = callback_url;
        if (test) params.test = '1';
        return this._call('api_create_qris', params);
    }
    async checkStatus(transactionId) {
        const r = await this._call('api_check_status', { transaction_id: transactionId });
        if (r.httpStatus === 429) {
            return { rateLimited: true, retryAfter: r.body?.retry_after ?? null, message: r.body?.message ?? 'Rate limited' };
        }
        return { rateLimited: false, ...r };
    }
}
const buatQrisService = new BuatQrisService();

// ============================================================
// AUTH
// ============================================================
function signToken(user) {
    return jwt.sign(
        { id: user.id, username: user.username, email: user.email },
        CONFIG.JWT_SECRET, { expiresIn: '8h' }
    );
}
function verifyToken(token) {
    if (!token) return null;
    try { return jwt.verify(token, CONFIG.JWT_SECRET); }
    catch { return null; }
}

const requireAuth = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token'); return res.status(401).json({ error: 'Silakan login dulu' }); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token'); return res.status(401).json({ error: 'User tidak ditemukan' }); }
    req.user = user;
    next();
};
const redirectIfNotLoggedIn = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token'); return res.redirect('/about'); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token'); return res.redirect('/about'); }
    req.user = user;
    next();
};
const redirectIfLoggedIn = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (decoded) return res.redirect('/dashboard');
    next();
};
const validateApiKey = (req, res, next) => {
    const apiKey = req.headers['x-api-key'] || req.query.api_key;
    if (!apiKey) return res.status(401).json({ success: false, error: 'API Key diperlukan.' });

    const key = CACHE.apiKeys.find(k => k.key === apiKey && k.is_active === true);
    if (!key) return res.status(401).json({ success: false, error: 'API Key tidak valid / nonaktif' });

    // update last_used (fire & forget)
    dbPatchJson('api_key', key.id, { last_used: new Date().toISOString() }).catch(() => {});

    req.apiKey = key;
    req.apiUser = getUserByUsername(key.username);
    next();
};

// ============================================================
// APP
// ============================================================
const app = express();
app.set('trust proxy', 1);

app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (req.path.startsWith('/api/v1/')) {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-API-Key');
        res.setHeader('Access-Control-Max-Age', '86400');
    } else {
        if (origin && CONFIG.ALLOWED_ORIGINS.includes(origin)) {
            res.setHeader('Access-Control-Allow-Origin', origin);
            res.setHeader('Access-Control-Allow-Credentials', 'true');
        }
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers',
            'Content-Type, X-API-Key, X-BuatQris-Signature, X-BuatQris-Event, X-BuatQris-Delivery, Authorization');
        res.setHeader('Access-Control-Max-Age', '86400');
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
});

// ============================================================
// WEBHOOK
// ============================================================
app.post('/webhook/buatqris', express.raw({ type: '*/*' }), async (req, res) => {
    const rawBody = req.body;
    const signing = CONFIG.BUATQRIS.SIGNING_SECRET;
    if (!signing || signing === 'belum-diisi') {
        console.warn('[BUATQRIS] Webhook ditolak: SIGNING_SECRET belum diisi');
        return res.sendStatus(401);
    }
    const sig = req.get('X-BuatQris-Signature') || '';
    const calc = 'sha256=' + crypto.createHmac('sha256', signing).update(rawBody).digest('hex');
    const sigBuf = Buffer.from(sig), calcBuf = Buffer.from(calc);
    const valid = sigBuf.length === calcBuf.length && crypto.timingSafeEqual(calcBuf, sigBuf);
    if (!valid) return res.sendStatus(401);

    let data;
    try { data = JSON.parse(rawBody.toString('utf8')); }
    catch { return res.sendStatus(400); }

    const event = req.get('X-BuatQris-Event') || data.event;
    const delivery = req.get('X-BuatQris-Delivery') || data.transaction_id || data.withdrawal_id;
    const idemKey = `${event}:${delivery}`;

    if (delivery && CACHE.webhooks.find(w => w.id === idemKey)) {
        console.log(`[BUATQRIS] Duplikat: ${idemKey}`);
        return res.sendStatus(200);
    }

    try {
        switch (event) {
            case 'payment.success': {
                const { error } = await supabase.rpc('credit_balance', { p_txid: data.transaction_id });
                if (error) { console.error('[BUATQRIS] RPC error:', error.message); break; }

                // RPC update Supabase langsung → refresh cache
                const row = await refreshQrisFromSupabase(data.transaction_id);
                if (row && !row.is_test) {
                    const user = await refreshUserFromSupabase(row.username);
                    const caption =
                        `<b>PEMBAYARAN BERHASIL</b>\n` +
                        `<blockquote>ID Transaksi: <code>${row.id}</code>\n` +
                        `Status: <b>Berhasil</b></blockquote>\n` +
                        `<blockquote>Nominal: <b>${rupiah(row.amount)}</b>\n` +
                        `Total Bayar: ${rupiah(row.total_amount)}\n` +
                        `Metode: ${row.qris_method || 'QRIS'}</blockquote>\n` +
                        `<b>User</b>: ${row.username}\n` +
                        `<b>Saldo Baru</b>: <b>${rupiah(user?.balance)}</b>\n` +
                        `<b>Waktu</b>: ${nowWIB()}\n\n` +
                        `<i>Saldo otomatis ditambahkan.</i>`;
                    sendTelegramPhoto('topup-success.jpg', caption);
                }
                break;
            }
            case 'payment.expired': {
                const row = dbGet('qris', data.transaction_id);
                if (row && row.status === 'pending') {
                    await dbPatchJson('qris', row.id, { status: 'expired' });
                    const caption =
                        `<b>INVOICE EXPIRED</b>\n` +
                        `<blockquote>ID Transaksi: <code>${row.id}</code>\n` +
                        `Status: <b>Expired</b></blockquote>\n` +
                        `<blockquote>Nominal: ${rupiah(row.amount)}\n` +
                        `User: ${row.username}</blockquote>\n` +
                        `<b>Waktu</b>: ${nowWIB()}`;
                    sendTelegramPhoto('topup-expired.jpg', caption);
                }
                break;
            }
            case 'payment.failed': {
                const row = dbGet('qris', data.transaction_id);
                if (row && row.status === 'pending') {
                    await dbPatchJson('qris', row.id, { status: 'failed' });
                    const caption =
                        `<b>PEMBAYARAN GAGAL</b>\n` +
                        `<blockquote>ID Transaksi: <code>${row.id}</code>\n` +
                        `Status: <b>Gagal</b></blockquote>\n` +
                        `<blockquote>Nominal: ${rupiah(row.amount)}\n` +
                        `User: ${row.username}</blockquote>\n` +
                        `<b>Waktu</b>: ${nowWIB()}`;
                    sendTelegramPhoto('topup-failed.jpg', caption);
                }
                break;
            }
            default:
                console.log('[BUATQRIS] Event tak dikenal:', event);
        }
        if (delivery) {
            try { await dbInsert({ id: idemKey, type: 'webhook', data: { event, delivery } }); }
            catch (_) {}
        }
    } catch (err) {
        console.error('[BUATQRIS] Webhook error:', err.message);
        return res.sendStatus(500);
    }
    return res.sendStatus(200);
});

// Refresh satu qris dari Supabase (setelah RPC)
async function refreshQrisFromSupabase(txid) {
    const { data, error } = await supabase
        .from('app_data').select('*')
        .eq('type', 'qris').eq('id', txid).maybeSingle();
    if (error || !data) return null;
    const entry = {
        id: data.id, username: data.username,
        created_at: data.created_at, updated_at: data.updated_at,
        ...(data.data || {})
    };
    const idx = CACHE.qris.findIndex(q => q.id === txid);
    if (idx >= 0) CACHE.qris[idx] = entry;
    else CACHE.qris.push(entry);
    return entry;
}

// ============================================================
// PARSER + STATIC
// ============================================================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use('/images', express.static(path.join(__dirname, 'images')));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// HALAMAN
// ============================================================
app.get('/', (req, res) => {
    if (verifyToken(req.cookies.token)) return res.redirect('/dashboard');
    res.redirect('/about');
});
app.get('/about', (req, res) => {
    if (req.cookies.token && !verifyToken(req.cookies.token)) res.clearCookie('token');
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});
app.get('/dashboard', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/login',     redirectIfLoggedIn,    (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/register',  redirectIfLoggedIn,    (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/topup',     redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'topup.html')));
app.get('/withdraw',  redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'withdraw.html')));
app.get('/profile',   redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'profile.html')));
app.get('/api-docs',  redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'api-docs.html')));

// ============================================================
// USER
// ============================================================
app.get('/api/user', (req, res) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token'); return res.status(401).json({ user: null }); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token'); return res.status(401).json({ user: null }); }
    res.json({ user: {
        username: user.username, email: user.email,
        balance: user.balance || 0, createdAt: user.created_at
    }});
});

app.get('/api/balance', requireAuth, (req, res) => {
    res.json({ balance: req.user.balance || 0, formatted: rupiah(req.user.balance) });
});

app.get('/api/topup-packages', (req, res) => res.json(TOPUP_PACKAGES));

// ============================================================
// API KEYS
// ============================================================
app.get('/api/api-keys', requireAuth, (req, res) => {
    const keys = CACHE.apiKeys
        .filter(k => k.username === req.user.username)
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    res.json({ success: true, keys });
});

app.post('/api/api-keys/generate', requireAuth, async (req, res) => {
    const { name } = req.body;
    if (!name || name.length < 3) {
        return res.status(400).json({ success: false, error: 'Nama API Key minimal 3 karakter' });
    }
    const id = 'key_' + Date.now();
    const keyData = {
        key: 'op_' + crypto.randomBytes(32).toString('hex'),
        name: name.trim(),
        is_active: true,
        created_at: new Date().toISOString(),
        last_used: null,
        expires_at: null
    };
    await dbInsert({ id, type: 'api_key', username: req.user.username, data: keyData });
    res.json({ success: true, message: 'API Key berhasil dibuat', key: { id, ...keyData } });
});

app.delete('/api/api-keys/:keyId', requireAuth, async (req, res) => {
    const row = dbGet('api_key', req.params.keyId);
    if (!row || row.username !== req.user.username) {
        return res.status(404).json({ success: false, error: 'API Key tidak ditemukan' });
    }
    const { error } = await supabase.from('app_data')
        .delete().eq('type', 'api_key').eq('id', req.params.keyId);
    if (error) return res.status(500).json({ success: false, error: error.message });

    const idx = CACHE.apiKeys.findIndex(k => k.id === req.params.keyId);
    if (idx >= 0) CACHE.apiKeys.splice(idx, 1);

    res.json({ success: true, message: 'API Key berhasil dihapus' });
});

app.patch('/api/api-keys/:keyId/toggle', requireAuth, async (req, res) => {
    const row = dbGet('api_key', req.params.keyId);
    if (!row || row.username !== req.user.username) {
        return res.status(404).json({ success: false, error: 'API Key tidak ditemukan' });
    }
    const newState = !row.is_active;
    await dbPatchJson('api_key', row.id, { is_active: newState });
    res.json({
        success: true,
        message: `API Key ${newState ? 'diaktifkan' : 'dinonaktifkan'}`,
        isActive: newState
    });
});

// ============================================================
// CHANGE PASSWORD
// ============================================================
app.post('/api/change-password', requireAuth, async (req, res) => {
    const { password } = req.body;
    if (!password || password.length < 6) {
        return res.status(400).json({ error: 'Password minimal 6 karakter' });
    }
    const hashed = await bcrypt.hash(password, 10);
    await dbPatchJson('user', req.user.username, { password: hashed });
    res.json({ success: true, message: 'Password updated' });
});

// ============================================================
// BUATQRIS — INVOICE
// ============================================================
app.post('/api/buatqris/invoice', requireAuth, async (req, res) => {
    try {
        const { amount, description, test } = req.body;
        const username = req.user.username;

        if (!amount || amount <= 0) return res.status(400).json({ success: false, message: 'Jumlah topup tidak valid' });
        if (amount < 1000) return res.status(400).json({ success: false, message: 'Minimal topup Rp 1.000' });
        if (amount > 5000000) return res.status(400).json({ success: false, message: 'Maksimal topup Rp 5.000.000' });

        const callbackUrl = `${CONFIG.APP_BASE_URL}/webhook/buatqris`;
        const isTest = test === true || test === '1' || test === 'true';

        const r = await buatQrisService.createQris({
            amount: Number(amount),
            description: description || `Topup saldo ${username}`,
            test: isTest, callback_url: callbackUrl
        });

        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, message: r.body?.message || 'Gagal membuat QRIS'
            });
        }

        const d = r.body.data;

        await dbInsert({
            id: d.transaction_id,
            type: 'qris',
            username,
            data: {
                transaction_id: d.transaction_id,
                amount: Number(amount),
                total_amount: d.total_amount,
                admin_fee: d.admin_fee,
                credit_amount: d.credit_amount,
                fee_by: d.fee_by,
                qris_method: d.qris_method,
                description: d.description,
                qr_url: d.qr_url,
                payment_url: d.payment_url,
                status: d.status,
                is_test: isTest,
                expired_at: d.expired_at,
                paid_at: null
            }
        });

        if (!isTest) {
            const caption =
                `<b>TRANSAKSI BARU</b>\n` +
                `<blockquote>ID Transaksi: <code>${d.transaction_id}</code>\n` +
                `Status: <b>Pending</b></blockquote>\n` +
                `<blockquote>Nominal: <b>${rupiah(d.amount)}</b>\n` +
                `Total Bayar: ${rupiah(d.total_amount)}\n` +
                `Admin Fee: ${rupiah(d.admin_fee)}\n` +
                `Metode: ${d.qris_method || 'QRIS'}</blockquote>\n` +
                `<b>User</b>: ${username}\n` +
                `<b>Expired</b>: ${d.expired_at || '-'}\n` +
                `<b>Waktu</b>: ${nowWIB()}\n\n` +
                `<i>Menunggu pembayaran. Belum ada saldo masuk.</i>`;
            sendTelegramPhoto('topup-pending.jpg', caption);
        }

        return res.json({ success: true, data: {
            transaction_id: d.transaction_id,
            amount: d.amount, total_amount: d.total_amount,
            admin_fee: d.admin_fee, credit_amount: d.credit_amount,
            fee_by: d.fee_by, qris_method: d.qris_method,
            qris_name_applied: d.qris_name_applied,
            status: d.status, expired_at: d.expired_at,
            qr_url: d.qr_url, qris_image: d.qris_image, payment_url: d.payment_url
        }});
    } catch (err) {
        console.error('BuatQris topup error:', err);
        return res.status(502).json({ success: false, message: 'Gagal menghubungi BuatQris: ' + err.message });
    }
});

// ============================================================
// BUATQRIS — STATUS
// ============================================================
app.get('/api/buatqris/status/:transactionId', requireAuth, async (req, res) => {
    try {
        const row = dbGet('qris', req.params.transactionId);
        if (!row || row.username !== req.user.username) {
            return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan' });
        }

        const r = await buatQrisService.checkStatus(req.params.transactionId);
        if (r.rateLimited) {
            return res.status(429).json({ success: false, error: 'rate_limited', message: r.message, retry_after: r.retryAfter });
        }
        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, message: r.body?.message || 'Gagal cek status'
            });
        }

        const d = r.body.data;
        if (row.status !== d.status) {
            if (d.status === 'success' && !row.paid_at) {
                const { error } = await supabase.rpc('credit_balance', { p_txid: row.id });
                if (error) console.error('[BUATQRIS] RPC error:', error.message);

                const updated = await refreshQrisFromSupabase(row.id);
                if (updated && !updated.is_test) {
                    const user = await refreshUserFromSupabase(updated.username);
                    const caption =
                        `<b>PEMBAYARAN BERHASIL</b>\n` +
                        `<blockquote>ID Transaksi: <code>${updated.id}</code>\n` +
                        `Status: <b>Berhasil</b></blockquote>\n` +
                        `<blockquote>Nominal: <b>${rupiah(updated.amount)}</b>\n` +
                        `Total Bayar: ${rupiah(updated.total_amount)}</blockquote>\n` +
                        `<b>User</b>: ${updated.username}\n` +
                        `<b>Saldo Baru</b>: <b>${rupiah(user?.balance)}</b>\n` +
                        `<b>Waktu</b>: ${nowWIB()}`;
                    sendTelegramPhoto('topup-success.jpg', caption);
                }
            } else if (d.status !== 'success') {
                await dbPatchJson('qris', row.id, { status: d.status });
            }
        }

        return res.json({ success: true, data: {
            transaction_id: d.transaction_id, status: d.status,
            amount: d.amount, total_amount: d.total_amount,
            credit_amount: d.credit_amount, updated_at: d.updated_at
        }});
    } catch (err) {
        return res.status(502).json({ success: false, message: 'Gagal menghubungi BuatQris: ' + err.message });
    }
});

// ============================================================
// LIST TRANSAKSI
// ============================================================
app.get('/api/buatqris/transactions', requireAuth, (req, res) => {
    const rows = dbListByUser('qris', req.user.username);
    res.json({ success: true, data: rows.map(r => ({ ...r, transaction_id: r.id, createdAt: r.created_at })) });
});

app.get('/api/transactions', requireAuth, (req, res) => {
    const legacy = dbListByUser('legacy', req.user.username)
        .map(r => ({ ...r, source: 'legacy', createdAt: r.created_at }));
    const current = dbListByUser('qris', req.user.username)
        .map(r => ({ ...r, transaction_id: r.id, source: 'buatqris', createdAt: r.created_at }));
    const merged = [...legacy, ...current]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(merged);
});

// ============================================================
// WITHDRAW
// ============================================================
app.get('/api/withdraw-methods', requireAuth, (req, res) => {
    res.json({ success: true, methods: CONFIG.WITHDRAW_METHODS });
});

app.post('/api/withdraw', requireAuth, async (req, res) => {
    try {
        const { amount, method, accountNumber, accountName } = req.body;
        const username = req.user.username;

        const methodConfig = CONFIG.WITHDRAW_METHODS.find(m => m.id === method);
        if (!methodConfig) return res.status(400).json({ success: false, error: 'Metode pembayaran tidak valid' });

        const amountNum = parseInt(amount, 10);
        if (!amountNum || amountNum <= 0) return res.status(400).json({ success: false, error: 'Jumlah withdraw tidak valid' });
        if (amountNum < CONFIG.WITHDRAW_MIN) return res.status(400).json({ success: false, error: `Minimal withdraw Rp ${CONFIG.WITHDRAW_MIN.toLocaleString()}` });
        if (amountNum > CONFIG.WITHDRAW_MAX) return res.status(400).json({ success: false, error: `Maksimal withdraw Rp ${CONFIG.WITHDRAW_MAX.toLocaleString()}` });
        if (!accountNumber || accountNumber.length < 5) return res.status(400).json({ success: false, error: 'Nomor akun tidak valid' });
        if (!accountName || accountName.length < 3) return res.status(400).json({ success: false, error: 'Nama pemilik akun tidak valid' });

        const user = getUserByUsername(username);
        if (!user) return res.status(404).json({ success: false, error: 'User tidak ditemukan' });

        const currentBalance = Number(user.balance || 0);
        if (amountNum > currentBalance) {
            return res.status(400).json({ success: false, error: `Saldo tidak cukup! Saldo Anda: Rp ${currentBalance.toLocaleString()}` });
        }

        const pending = CACHE.withdraws.find(w => w.username === username && w.status === 'pending');
        if (pending) {
            return res.status(400).json({ success: false, error: 'Anda masih memiliki permintaan withdraw yang sedang diproses.' });
        }

        const newBalance = currentBalance - amountNum;
        await dbPatchJson('user', username, { balance: newBalance });

        const withdrawId = 'WD-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();

        await dbInsert({
            id: withdrawId, type: 'withdraw', username,
            data: {
                amount: amountNum,
                method, method_name: methodConfig.name,
                account_number: accountNumber, account_name: accountName,
                status: 'pending', processed_at: null, note: ''
            }
        });

        await dbInsert({
            id: withdrawId, type: 'legacy', username,
            data: {
                type: 'withdraw', method, method_name: methodConfig.name,
                account_number: accountNumber, account_name: accountName,
                nominal: amountNum, amount: amountNum, status: 'pending'
            }
        });

        const caption =
            `<b>PENGAJUAN WITHDRAW BARU</b>\n` +
            `<blockquote>ID Withdraw: <code>${withdrawId}</code>\n` +
            `Status: <b>Menunggu Diproses</b></blockquote>\n` +
            `<blockquote>Nominal: <b>${rupiah(amountNum)}</b>\n` +
            `Metode: ${methodConfig.name}\n` +
            `No. Akun: <code>${accountNumber}</code>\n` +
            `Atas Nama: ${accountName}</blockquote>\n` +
            `<b>User</b>: ${username}\n` +
            `<b>Saldo Sisa</b>: ${rupiah(newBalance)}\n` +
            `<b>Waktu</b>: ${nowWIB()}\n` +
            `<b>IP</b>: <code>${req.ip}</code>\n\n` +
            `<i>Mohon diproses maksimal 1x24 jam.</i>`;
        sendTelegramPhoto('withdraw.jpg', caption);

        res.json({
            success: true,
            message: 'Permintaan withdraw berhasil diajukan. Admin akan memproses maksimal 1x24 jam.',
            data: {
                withdrawal_id: withdrawId, amount: amountNum,
                method: methodConfig.name, accountNumber, accountName,
                status: 'pending', createdAt: new Date().toISOString()
            },
            newBalance
        });
    } catch (error) {
        console.error('Withdraw error:', error);
        res.status(500).json({ success: false, error: error.message || 'Terjadi kesalahan' });
    }
});

app.get('/api/withdraws', requireAuth, (req, res) => {
    const rows = dbListByUser('withdraw', req.user.username);
    res.json({ success: true, data: rows.map(r => ({ id: r.id, ...r, createdAt: r.created_at })) });
});

// ============================================================
// API PUBLIK v1
// ============================================================
app.get('/api/v1/balance', validateApiKey, (req, res) => {
    res.json({ success: true, data: {
        username: req.apiUser.username,
        balance: req.apiUser.balance || 0,
        formatted: rupiah(req.apiUser.balance)
    }});
});

app.get('/api/v1/transactions', validateApiKey, (req, res) => {
    const legacy = dbListByUser('legacy', req.apiKey.username)
        .map(r => ({ ...r, source: 'legacy', createdAt: r.created_at }));
    const current = dbListByUser('qris', req.apiKey.username)
        .map(r => ({ ...r, transaction_id: r.id, source: 'buatqris', createdAt: r.created_at }));
    const merged = [...legacy, ...current]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ success: true, data: merged });
});

app.post('/api/v1/invoice', validateApiKey, async (req, res) => {
    try {
        const { amount, description, test } = req.body;
        const username = req.apiKey.username;

        if (!amount || amount <= 0) return res.status(400).json({ success: false, error: 'Jumlah topup tidak valid' });
        if (amount < 1000) return res.status(400).json({ success: false, error: 'Minimal topup Rp 1.000' });
        if (amount > 5000000) return res.status(400).json({ success: false, error: 'Maksimal topup Rp 5.000.000' });

        const callbackUrl = `${CONFIG.APP_BASE_URL}/webhook/buatqris`;
        const isTest = test === true || test === '1' || test === 'true';

        const r = await buatQrisService.createQris({
            amount: Number(amount),
            description: description || `Topup saldo ${username}`,
            test: isTest, callback_url: callbackUrl
        });

        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, error: r.body?.message || 'Gagal membuat QRIS'
            });
        }

        const d = r.body.data;
        await dbInsert({
            id: d.transaction_id, type: 'qris', username,
            data: {
                transaction_id: d.transaction_id,
                amount: Number(amount), total_amount: d.total_amount,
                admin_fee: d.admin_fee, credit_amount: d.credit_amount,
                fee_by: d.fee_by, qris_method: d.qris_method,
                description: d.description, qr_url: d.qr_url, payment_url: d.payment_url,
                status: d.status, is_test: isTest,
                expired_at: d.expired_at, paid_at: null
            }
        });

        if (!isTest) {
            const caption =
                `<b>TRANSAKSI BARU (API)</b>\n` +
                `<blockquote>ID Transaksi: <code>${d.transaction_id}</code>\n` +
                `Status: <b>Pending</b></blockquote>\n` +
                `<blockquote>Nominal: <b>${rupiah(d.amount)}</b>\n` +
                `Total Bayar: ${rupiah(d.total_amount)}\n` +
                `Metode: ${d.qris_method || 'QRIS'}</blockquote>\n` +
                `<b>User</b>: ${username}\n` +
                `<b>Waktu</b>: ${nowWIB()}`;
            sendTelegramPhoto('topup-pending.jpg', caption);
        }

        res.json({ success: true, data: {
            transaction_id: d.transaction_id,
            amount: d.amount, total_amount: d.total_amount,
            admin_fee: d.admin_fee, credit_amount: d.credit_amount,
            qris_method: d.qris_method, status: d.status,
            expired_at: d.expired_at, qr_url: d.qr_url,
            qris_image: d.qris_image, payment_url: d.payment_url
        }});
    } catch (error) {
        res.status(502).json({ success: false, error: error.message });
    }
});

app.get('/api/v1/status/:transactionId', validateApiKey, async (req, res) => {
    try {
        const r = await buatQrisService.checkStatus(req.params.transactionId);
        if (r.rateLimited) {
            return res.status(429).json({ success: false, error: 'rate_limited', message: r.message, retry_after: r.retryAfter });
        }
        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, error: r.body?.message || 'Gagal cek status'
            });
        }
        const d = r.body.data;
        res.json({ success: true, data: {
            transaction_id: d.transaction_id, status: d.status,
            amount: d.amount, total_amount: d.total_amount,
            credit_amount: d.credit_amount, updated_at: d.updated_at
        }});
    } catch (error) {
        res.status(502).json({ success: false, error: error.message });
    }
});

app.all('/api/v1/withdraw', validateApiKey, (req, res) => {
    res.status(503).json({ success: false, error: 'maintenance', message: 'Withdraw via API belum tersedia. Gunakan dashboard.' });
});

// ============================================================
// AUTH ROUTES
// ============================================================
app.post('/register', async (req, res) => {
    try {
        const { username, password, email } = req.body;
        if (!username || !password || !email) return res.status(400).json({ error: 'Semua field harus diisi!' });

        const existing = getUserByUsername(username);
        if (existing) return res.status(400).json({ error: 'Username sudah digunakan!' });

        const hashed = await bcrypt.hash(password, 10);
        await dbInsert({
            id: username, type: 'user', username,
            data: { username, email, password: hashed, balance: 0 }
        });

        const caption =
            `<b>USER BARU TERDAFTAR</b>\n` +
            `<blockquote>Username: <b>${username}</b>\n` +
            `Email: ${email}\n` +
            `Saldo Awal: ${rupiah(0)}</blockquote>\n` +
            `<b>Waktu</b>: ${nowWIB()}\n` +
            `<b>IP</b>: <code>${req.ip}</code>\n\n` +
            `<i>Registrasi berhasil.</i>`;
        sendTelegramPhoto('user-baru.jpg', caption);

        res.json({ success: true, message: 'Registrasi berhasil!', user: username });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) return res.status(400).json({ error: 'Semua field harus diisi!' });

        const user = getUserByUsername(username);
        if (!user) return res.status(400).json({ error: 'Username tidak ditemukan!' });

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(400).json({ error: 'Password salah!' });

        const token = signToken(user);
        res.cookie('token', token, {
            httpOnly: true, secure: true, sameSite: 'lax',
            maxAge: 8 * 60 * 60 * 1000
        });

        const caption =
            `<b>USER LOGIN</b>\n` +
            `<blockquote>Username: <b>${user.username}</b>\n` +
            `Saldo: ${rupiah(user.balance)}</blockquote>\n` +
            `<b>Waktu</b>: ${nowWIB()}\n` +
            `<b>IP</b>: <code>${req.ip}</code>`;
        sendTelegramPhoto('login.jpg', caption);

        res.json({ success: true, message: 'Login berhasil!', balance: user.balance || 0 });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/logout', (req, res) => {
    res.clearCookie('token', { httpOnly: true, secure: true, sameSite: 'lax' });
    res.json({ success: true, message: 'Logout berhasil!', redirect: '/about' });
});

// ============================================================
// ADMIN — manual reload cache
// ============================================================
app.post('/api/admin/reload-cache', async (req, res) => {
    // proteksi sederhana: header X-Admin-Key
    const adminKey = req.headers['x-admin-key'];
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    const ok = await loadFromSupabase();
    res.json({
        success: ok,
        users: CACHE.users.length,
        apiKeys: CACHE.apiKeys.length,
        qris: CACHE.qris.length,
        withdraws: CACHE.withdraws.length,
        loadedAt: CACHE.loadedAt
    });
});

// ============================================================
// ERROR HANDLER
// ============================================================
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: err.message || 'Terjadi kesalahan server' });
});

// ============================================================
// START — load Supabase dulu, baru listen
// ============================================================
(async () => {
    const ok = await loadFromSupabase();
    if (!ok) {
        console.warn('[STARTUP] ⚠️  Gagal load dari Supabase. Server tetap jalan, cache kosong.');
    }

    startPeriodicSync();

    app.listen(CONFIG.PORT, () => {
        console.log('========================================');
        console.log('MARCHANT ID (BuatQris + Supabase) — CACHE MODE');
        console.log(`Server: http://localhost:${CONFIG.PORT}`);
        console.log(`Cache : ${CACHE.users.length} users | ${CACHE.qris.length} qris | ${CACHE.withdraws.length} withdraws`);
        console.log(`Loaded: ${CACHE.loadedAt || '-'}`);
        console.log('========================================\n');
        debugTelegramInfo();
    });
})();