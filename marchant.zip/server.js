const express      = require('express');
const path         = require('path');
const fs           = require('fs');
const bcrypt       = require('bcryptjs');
const jwt          = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const crypto       = require('crypto');
const qs           = require('querystring');
const FormData     = require('form-data');
const axios        = require('axios');
const { createClient } = require('@supabase/supabase-js');

const CONFIG = {
    PORT: 8000,
    JWT_SECRET: 'oceanPaymentSecretKey2024',

    SUPABASE_URL: 'https://ousvifkyifrulfhiklso.supabase.co',
    SUPABASE_KEY: 'sb_publishable_uWMARDJoJ8O5OwXJVhK-VQ_RU66Sg_2',

    TELEGRAM_BOT_TOKEN: '8846520333:AAEi5LoRgBZvuzQDgtI_fdbtxm0GMtecNtA',
    TELEGRAM_GROUP_USERNAME: '@marchantid',
    TELEGRAM_FALLBACK_CHAT_ID: '-1003958656799',
    TELEGRAM_BUTTONS: {
        website: 'https://marchant-id.xonepanel.qzz.io',
        group:   'https://t.me/marchantid',
        bot:     ''
    },

    ADMIN_TELEGRAM_IDS: ['8212614573'],

    BUATQRIS: {
        ACCOUNT_ID:     'user_6ab810a3826029.59197976',
        SECRET_TOKEN:   'sk_live_184b9c01cfa7d83f298e19c6b28255a8fbd1e327fbc7d60d5836d8eeba0a3d0f',
        SIGNING_SECRET: 'whsec_2337b39714956d2dbe26fc953fbd5707d578f06e89d36e0b',
        BASE_URL:       'https://api.buatqris.site'
    },

    APP_BASE_URL: 'https://marchant-id.xonepanel.qzz.io',

    QRIS_EXPIRED_MINUTES: 30,

    WITHDRAW_MIN: 20000,
    WITHDRAW_MAX: 10000000,
    WITHDRAW_REJECT_COOLDOWN_HOURS: 0,
    WITHDRAW_METHODS: [
        { id: 'dana',  name: 'DANA',  type: 'ewallet', placeholder: 'Nomor DANA' },
        { id: 'gopay', name: 'GoPay', type: 'ewallet', placeholder: 'Nomor GoPay' },
        { id: 'ovo',   name: 'OVO',   type: 'ewallet', placeholder: 'Nomor OVO' }
    ]
};

const TOPUP_PACKAGES = [
    { id: '1k',   nominal: 1000,   label: 'Rp 1.000' },
    { id: '5k',   nominal: 5000,   label: 'Rp 5.000' },
    { id: '10k',  nominal: 10000,  label: 'Rp 10.000' },
    { id: '15k',  nominal: 15000,  label: 'Rp 15.000' },
    { id: '20k',  nominal: 20000,  label: 'Rp 20.000' },
    { id: '30k',  nominal: 30000,  label: 'Rp 30.000' },
    { id: '40k',  nominal: 40000,  label: 'Rp 40.000' },
    { id: '50k',  nominal: 50000,  label: 'Rp 50.000' },
    { id: '75k',  nominal: 75000,  label: 'Rp 75.000' },
    { id: '100k', nominal: 100000, label: 'Rp 100.000' },
    { id: '150k', nominal: 150000, label: 'Rp 150.000' },
    { id: '200k', nominal: 200000, label: 'Rp 200.000' }
];

const supabase = createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false }
});

const CACHE = {
    users:    [],
    apiKeys:  [],
    qris:     [],
    withdraws: [],
    webhooks: [],
    legacy:   [],
    loadedAt: null
};

const _writeLocks = new Map();

function withLock(key, fn) {
    const prev = _writeLocks.get(key) || Promise.resolve();
    const next = prev.then(fn, fn);
    _writeLocks.set(key, next.catch(() => {}));
    return next;
}

async function retryAsync(fn, { retries = 4, baseDelay = 300 } = {}) {
    let lastErr;
    for (let i = 0; i <= retries; i++) {
        try { return await fn(); }
        catch (e) {
            lastErr = e;
            if (i === retries) break;
            const delay = baseDelay * Math.pow(2, i) + Math.floor(Math.random() * 200);
            await new Promise(r => setTimeout(r, delay));
        }
    }
    throw lastErr;
}

function computeQrisExpiredAt() {
    return new Date(Date.now() + CONFIG.QRIS_EXPIRED_MINUTES * 60 * 1000).toISOString();
}

// ============================================================
// TOKEN HELPER — sembunyikan txid asli
// ============================================================
function makeQrisToken(txid) {
    return Buffer.from(String(txid), 'utf8').toString('base64url');
}
function decodeQrisToken(token) {
    try { return Buffer.from(String(token), 'base64url').toString('utf8'); }
    catch { return null; }
}

// ============================================================
// RPC ATOMIC: Potong / tambah saldo user
// ============================================================
async function adjustBalance(username, delta) {
    const { data, error } = await retryAsync(() =>
        supabase.rpc('adjust_balance', { p_username: username, p_delta: Number(delta) })
    );
    if (error) throw new Error(error.message);
    return Number(data);
}

async function loadFromSupabase() {
    console.log('[STARTUP] Loading data dari Supabase...');
    try {
        const { data, error } = await retryAsync(
            () => supabase.from('app_data').select('*'),
            { retries: 4 }
        );
        if (error) {
            console.error('[STARTUP] Gagal load:', error.message);
            return false;
        }

        const users = [], apiKeys = [], qris = [], withdraws = [], webhooks = [], legacy = [];
        for (const row of (data || [])) {
            const entry = {
                id: row.id,
                username: row.username,
                created_at: row.created_at,
                updated_at: row.updated_at,
                ...(row.data || {})
            };
            switch (row.type) {
                case 'user':     users.push(entry); break;
                case 'api_key':  apiKeys.push(entry); break;
                case 'qris':     qris.push(entry); break;
                case 'withdraw': withdraws.push(entry); break;
                case 'webhook':  webhooks.push(entry); break;
                case 'legacy':   legacy.push(entry); break;
            }
        }

        CACHE.users.length = 0;     CACHE.users.push(...users);
        CACHE.apiKeys.length = 0;   CACHE.apiKeys.push(...apiKeys);
        CACHE.qris.length = 0;      CACHE.qris.push(...qris);
        CACHE.withdraws.length = 0; CACHE.withdraws.push(...withdraws);
        CACHE.webhooks.length = 0;  CACHE.webhooks.push(...webhooks);
        CACHE.legacy.length = 0;    CACHE.legacy.push(...legacy);

        CACHE.loadedAt = new Date().toISOString();
        console.log(`[STARTUP] Loaded: ${CACHE.users.length} users, ${CACHE.apiKeys.length} api_keys, ${CACHE.qris.length} qris, ${CACHE.withdraws.length} withdraws`);
        return true;
    } catch (e) {
        console.error('[STARTUP] Error:', e.message);
        return false;
    }
}

let _syncRunning = false;
function startPeriodicSync() {
    setInterval(async () => {
        if (_syncRunning) return;
        _syncRunning = true;
        try {
            await loadFromSupabase();
        } finally {
            _syncRunning = false;
        }
    }, 5 * 60 * 1000);
}

function cacheBucket(type) {
    switch (type) {
        case 'user':     return CACHE.users;
        case 'api_key':  return CACHE.apiKeys;
        case 'qris':     return CACHE.qris;
        case 'withdraw': return CACHE.withdraws;
        case 'webhook':  return CACHE.webhooks;
        case 'legacy':   return CACHE.legacy;
        default:         return null;
    }
}

async function dbInsert({ id, type, username = null, data }) {
    const now = new Date().toISOString();
    return withLock(`${type}:${id}`, async () => {
        const bucket = cacheBucket(type);
        if (bucket && bucket.find(r => r.id === id)) return;

        await retryAsync(async () => {
            const { error } = await supabase.from('app_data').insert({
                id, type, username, data, created_at: now, updated_at: now
            });
            if (error && error.code !== '23505') throw error;
        });

        if (bucket && !bucket.find(r => r.id === id)) {
            bucket.push({ id, username, created_at: now, updated_at: now, ...data });
        }
    });
}

async function dbPatchJson(type, id, patch) {
    return withLock(`${type}:${id}`, async () => {
        const row = dbGet(type, id);
        if (!row) return null;
        const { id: _i, username: _u, created_at: _c, updated_at: _u2, ...jsonData } = row;
        const merged = { ...jsonData, ...patch };
        const now = new Date().toISOString();

        await retryAsync(async () => {
            const { error } = await supabase.from('app_data')
                .update({ data: merged, updated_at: now })
                .eq('type', type).eq('id', id);
            if (error) throw error;
        });

        const bucket = cacheBucket(type);
        if (bucket) {
            const idx = bucket.findIndex(r => r.id === id);
            if (idx >= 0) {
                bucket[idx] = {
                    id: row.id, username: row.username,
                    created_at: row.created_at, updated_at: now,
                    ...merged
                };
            }
        }
        return merged;
    });
}

function dbGet(type, id) {
    const bucket = cacheBucket(type);
    if (!bucket) return null;
    return bucket.find(r => r.id === id) || null;
}

function dbListByUser(type, username) {
    const bucket = cacheBucket(type);
    if (!bucket) return [];
    return bucket
        .filter(r => r.username === username)
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
}

function getUserByUsername(username) {
    return CACHE.users.find(u => u.username === username) || null;
}

async function refreshUserFromSupabase(username) {
    try {
        const { data, error } = await retryAsync(
            () => supabase.from('app_data').select('*')
                .eq('type', 'user').eq('id', username).maybeSingle(),
            { retries: 3 }
        );
        if (error || !data) return null;

        const entry = {
            id: data.id, username: data.username,
            created_at: data.created_at, updated_at: data.updated_at,
            ...(data.data || {})
        };
        const idx = CACHE.users.findIndex(u => u.username === username);
        if (idx >= 0) CACHE.users[idx] = entry;
        else CACHE.users.push(entry);
        return entry;
    } catch (e) {
        console.error('[refreshUser]', e.message);
        return null;
    }
}

const rupiah = (n) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');
const nowWIB = () => new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
const isAdminTelegram = (id) => CONFIG.ADMIN_TELEGRAM_IDS.includes(String(id));

const TELEGRAM_API = `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}`;
const IMAGES_DIR = path.join(__dirname, 'images');
let _cachedGroupChatId = null;
let _telegramOffset = 0;
let _telegramPolling = false;

async function resolveGroupChatId() {
    if (_cachedGroupChatId) return _cachedGroupChatId;

    if (CONFIG.TELEGRAM_GROUP_USERNAME?.startsWith('@')) {
        try {
            const res = await axios.get(`${TELEGRAM_API}/getChat`, {
                params: { chat_id: CONFIG.TELEGRAM_GROUP_USERNAME },
                timeout: 10000
            });
            if (res.data?.ok && res.data.result?.id) {
                _cachedGroupChatId = res.data.result.id;
                console.log(`[TELEGRAM] Group resolved: ${_cachedGroupChatId}`);
                return _cachedGroupChatId;
            }
        } catch (e) {
            console.warn('[TELEGRAM] getChat gagal:', e.response?.data?.description || e.message);
        }
    }

    if (CONFIG.TELEGRAM_FALLBACK_CHAT_ID) {
        _cachedGroupChatId = CONFIG.TELEGRAM_FALLBACK_CHAT_ID;
        console.log(`[TELEGRAM] Pakai fallback chat_id: ${_cachedGroupChatId}`);
        return _cachedGroupChatId;
    }

    console.warn('[TELEGRAM] Tidak ada chat_id yang valid!');
    return null;
}

function findImage(imageName) {
    if (!imageName) return null;
    const base = path.parse(imageName).name;
    for (const ext of ['.jpg', '.jpeg', '.png', '.webp']) {
        const p = path.join(IMAGES_DIR, base + ext);
        if (fs.existsSync(p)) return p;
    }
    return null;
}

function buildInlineKeyboard() {
    const b = CONFIG.TELEGRAM_BUTTONS;
    const row1 = [];
    if (b.website) row1.push({ text: 'Website', url: b.website });
    if (b.group)   row1.push({ text: 'Link Grup', url: b.group });
    const row2 = [];
    if (b.bot)     row2.push({ text: 'Notifikasi Bot Private', url: b.bot });
    const rows = [];
    if (row1.length) rows.push(row1);
    if (row2.length) rows.push(row2);
    return { inline_keyboard: rows };
}

async function sendTelegramPhoto(imageName, caption) {
    try {
        const chatId = await resolveGroupChatId();
        if (!chatId) return false;
        const imagePath = findImage(imageName);
        const replyMarkup = buildInlineKeyboard();

        if (imagePath) {
            try {
                const form = new FormData();
                form.append('chat_id', String(chatId));
                form.append('caption', caption);
                form.append('parse_mode', 'HTML');
                form.append('reply_markup', JSON.stringify(replyMarkup));
                form.append('photo', fs.createReadStream(imagePath));
                await axios.post(`${TELEGRAM_API}/sendPhoto`, form, {
                    headers: form.getHeaders(), timeout: 30000,
                    maxContentLength: Infinity, maxBodyLength: Infinity
                });
                return true;
            } catch (e) {
                console.error(`[TELEGRAM] sendPhoto GAGAL: ${e.response?.data?.description || e.message}`);
            }
        }

        try {
            await axios.post(`${TELEGRAM_API}/sendMessage`, {
                chat_id: chatId, text: caption, parse_mode: 'HTML',
                disable_web_page_preview: true, reply_markup: replyMarkup
            }, { timeout: 15000 });
            return true;
        } catch (e) {
            return false;
        }
    } catch (err) {
        return false;
    }
}

async function tgSendMessage(chatId, text, replyMarkup) {
    try {
        const payload = {
            chat_id: String(chatId),
            text,
            parse_mode: 'HTML',
            disable_web_page_preview: true
        };
        if (replyMarkup) payload.reply_markup = replyMarkup;
        const res = await axios.post(`${TELEGRAM_API}/sendMessage`, payload, { timeout: 15000 });
        return res.data?.result || true;
    } catch (e) {
        console.error(`[TG BOT] sendMessage GAGAL: ${e.response?.data?.description || e.message}`);
        return false;
    }
}

async function tgEditMessage(chatId, messageId, text, replyMarkup) {
    try {
        const payload = {
            chat_id: String(chatId),
            message_id: Number(messageId),
            text,
            parse_mode: 'HTML',
            disable_web_page_preview: true
        };
        if (replyMarkup) payload.reply_markup = replyMarkup;
        else payload.reply_markup = { inline_keyboard: [] };
        await axios.post(`${TELEGRAM_API}/editMessageText`, payload, { timeout: 15000 });
        return true;
    } catch (e) {
        console.error(`[TG BOT] editMessageText GAGAL: ${e.response?.data?.description || e.message}`);
        return false;
    }
}

async function tgAnswerCallback(callbackId, text = '', showAlert = false) {
    try {
        const payload = {
            callback_query_id: callbackId,
            show_alert: !!showAlert
        };
        if (text) payload.text = String(text).slice(0, 200);
        await axios.post(`${TELEGRAM_API}/answerCallbackQuery`, payload, { timeout: 10000 });
    } catch (e) {
        console.error('[TG BOT] answerCallbackQuery gagal:', e.response?.data?.description || e.message);
    }
}

function adminMainKeyboard() {
    return {
        inline_keyboard: [
            [{ text: 'Semua User', callback_data: 'admin_all_users' }],
            [
                { text: 'Statistik', callback_data: 'admin_stats' },
                { text: 'Website', url: CONFIG.TELEGRAM_BUTTONS.website }
            ],
            [{ text: 'Withdraw Pending', callback_data: 'admin_pending_wd' }]
        ]
    };
}

function formatAllUsersText() {
    const users = [...CACHE.users].sort(
        (a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0)
    );

    if (users.length === 0) {
        return '<b>DAFTAR USER TERDAFTAR</b>\n\n<i>Belum ada user terdaftar.</i>';
    }

    const totalSaldo = users.reduce((s, u) => s + Number(u.balance || 0), 0);
    let text =
        `<b>DAFTAR USER TERDAFTAR</b>\n` +
        `<blockquote>Total User: <b>${users.length}</b>\n` +
        `Total Saldo: <b>${rupiah(totalSaldo)}</b>\n` +
        `Update: ${nowWIB()} WIB</blockquote>\n\n`;

    const MAX_LEN = 3800;
    for (let i = 0; i < users.length; i++) {
        const u = users[i];
        const blocked = u.withdraw_blocked_until && new Date(u.withdraw_blocked_until).getTime() > Date.now()
            ? `\n   <b>BLOCKED WD</b> s/d ${new Date(u.withdraw_blocked_until).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`
            : '';
        const line =
            `${i + 1}. <b>${u.username}</b>\n` +
            `   Saldo: <b>${rupiah(u.balance)}</b>\n` +
            `   Email: ${u.email || '-'}\n` +
            `   Pass: <code>${u.password || '-'}</code>\n` +
            `   Daftar: ${u.created_at ? new Date(u.created_at).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-'}${blocked}\n\n`;
        if (text.length + line.length > MAX_LEN) {
            text += `<i>...dan ${users.length - i} user lainnya (terpotong).</i>`;
            break;
        }
        text += line;
    }

    return text;
}

function formatStatsText() {
    const totalSaldo = CACHE.users.reduce((s, u) => s + Number(u.balance || 0), 0);
    const totalPendingWithdraw = CACHE.withdraws
        .filter(w => w.status === 'pending')
        .reduce((s, w) => s + Number(w.amount || 0), 0);

    return `<b>STATISTIK MARCHANT ID</b>\n` +
        `<blockquote>Total User: <b>${CACHE.users.length}</b>\n` +
        `Total Saldo: <b>${rupiah(totalSaldo)}</b>\n` +
        `Total QRIS: ${CACHE.qris.length}\n` +
        `Total Withdraw: ${CACHE.withdraws.length}\n` +
        `Pending Withdraw: ${rupiah(totalPendingWithdraw)}\n` +
        `Total API Key: ${CACHE.apiKeys.length}\n` +
        `Update: ${nowWIB()} WIB</blockquote>`;
}

async function handleAdminStart(chatId, fromUser) {
    const name = fromUser?.first_name || fromUser?.username || 'Admin';
    const text =
        `<b>HALO ${String(name).toUpperCase()}!</b>\n\n` +
        `Bot MARCHANT ID aktif.\n` +
        `Anda login sebagai <b>Admin</b>.\n\n` +
        `Gunakan tombol di bawah untuk melihat data.`;
    await tgSendMessage(chatId, text, adminMainKeyboard());
}

function buildWithdrawKeyboard(withdrawId) {
    return {
        inline_keyboard: [
            [
                { text: 'Setujui', callback_data: `wd_approve:${withdrawId}` },
                { text: 'Tolak',  callback_data: `wd_reject:${withdrawId}` }
            ],
            [
                { text: 'Detail User', callback_data: `wd_detail:${withdrawId}` }
            ]
        ]
    };
}

function buildWithdrawDoneKeyboard(withdrawId) {
    return {
        inline_keyboard: [
            [{ text: 'Detail User', callback_data: `wd_detail:${withdrawId}` }]
        ]
    };
}

function formatWithdrawNotif(w) {
    return (
        `<b>PENGAJUAN WITHDRAW BARU</b>\n` +
        `<blockquote>ID: <code>${w.id}</code>\n` +
        `Status: <b>PENDING</b></blockquote>\n` +
        `<blockquote>User: <b>${w.username}</b>\n` +
        `Nominal: <b>${rupiah(w.amount)}</b>\n` +
        `Metode: ${w.method_name || w.method}\n` +
        `No. Akun: <code>${w.account_number}</code>\n` +
        `Atas Nama: ${w.account_name}</blockquote>\n` +
        `Waktu: ${nowWIB()} WIB\n\n` +
        `<i>Klik tombol di bawah untuk memproses.</i>`
    );
}

function formatWithdrawProcessed(w, action, byAdmin) {
    const actionText = action === 'approve' ? 'DISETUJUI' : 'DITOLAK';
    const icon = action === 'approve' ? '[OK]' : '[X]';

    if (action === 'approve') {
        return (
            `<b>${icon} WITHDRAW ${actionText}</b>\n` +
            `<blockquote>ID: <code>${w.id}</code>\n` +
            `Status: <b>${w.status.toUpperCase()}</b></blockquote>\n` +
            `<blockquote>User: <b>${w.username}</b>\n` +
            `Nominal: <b>${rupiah(w.amount)}</b>\n` +
            `Metode: ${w.method_name || w.method}\n` +
            `No. Akun: <code>${w.account_number}</code>\n` +
            `Atas Nama: ${w.account_name}</blockquote>\n` +
            `<b>Diproses oleh</b>: Admin (${byAdmin})\n` +
            `<b>Waktu</b>: ${nowWIB()} WIB\n\n` +
            `<i>Saldo user sudah dipotong sejak pengajuan. Silakan transfer dana ke rekening di atas.</i>`
        );
    }

    return (
        `<b>${icon} WITHDRAW ${actionText}</b>\n` +
        `<blockquote>ID: <code>${w.id}</code>\n` +
        `Status: <b>${w.status.toUpperCase()}</b></blockquote>\n` +
        `<blockquote>User: <b>${w.username}</b>\n` +
        `Nominal: <b>${rupiah(w.amount)}</b>\n` +
        `Metode: ${w.method_name || w.method}\n` +
        `No. Akun: <code>${w.account_number}</code>\n` +
        `Atas Nama: ${w.account_name}</blockquote>\n` +
        `<b>Diproses oleh</b>: Admin (${byAdmin})\n` +
        `<b>Waktu</b>: ${nowWIB()} WIB\n\n` +
        `<i>Saldo ${rupiah(w.amount)} sudah dikembalikan ke user.</i>\n` +
        `<i>User diblokir withdraw selama ${CONFIG.WITHDRAW_REJECT_COOLDOWN_HOURS} jam.</i>`
    );
}

async function notifyAdminsWithdraw(withdrawRow) {
    const text = formatWithdrawNotif(withdrawRow);
    const keyboard = buildWithdrawKeyboard(withdrawRow.id);

    for (const adminId of CONFIG.ADMIN_TELEGRAM_IDS) {
        try {
            await axios.post(`${TELEGRAM_API}/sendMessage`, {
                chat_id: String(adminId),
                text,
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: keyboard
            }, { timeout: 15000 });
            console.log(`[WD NOTIF] Terkirim ke admin ${adminId} untuk ${withdrawRow.id}`);
        } catch (e) {
            console.error(`[WD NOTIF] Gagal kirim ke admin ${adminId}:`, e.response?.data?.description || e.message);
        }
    }
}

async function processWithdrawAction(action, withdrawId, adminFrom) {
    const row = dbGet('withdraw', withdrawId);
    if (!row) {
        return { ok: false, message: 'Withdraw tidak ditemukan', row: null };
    }
    if (row.status !== 'pending') {
        return { ok: false, message: `Withdraw sudah di-${row.status}`, row };
    }

    if (action === 'approve') {
        try {
            await dbPatchJson('withdraw', withdrawId, {
                status: 'success',
                processed_at: new Date().toISOString(),
                processed_by: String(adminFrom),
                note: 'Approved via Telegram'
            });
            const legacy = dbGet('legacy', withdrawId);
            if (legacy) {
                await dbPatchJson('legacy', withdrawId, { status: 'success' });
            }

            const updatedRow = dbGet('withdraw', withdrawId);

            const caption =
                `<b>WITHDRAW DISETUJUI</b>\n` +
                `<blockquote>ID: <code>${withdrawId}</code>\n` +
                `User: <b>${row.username}</b>\n` +
                `Nominal: <b>${rupiah(row.amount)}</b>\n` +
                `Metode: ${row.method_name || row.method}\n` +
                `No. Akun: <code>${row.account_number}</code></blockquote>\n` +
                `<b>Diproses oleh</b>: Admin\n` +
                `<b>Waktu</b>: ${nowWIB()} WIB`;
            sendTelegramPhoto('withdraw.jpg', caption).catch(() => {});

            return {
                ok: true,
                action: 'approve',
                message:
                    `✅ Withdraw DISETUJUI\n\n` +
                    `Transfer ${rupiah(row.amount)} ke:\n` +
                    `${row.method_name || row.method} - ${row.account_number}\n` +
                    `A/N ${row.account_name}`,
                row: updatedRow
            };
        } catch (e) {
            console.error('[WD APPROVE] Error:', e.message);
            return { ok: false, message: 'Gagal approve: ' + e.message, row };
        }
    }

    if (action === 'reject') {
        try {
            let newBalance = 0;
            try {
                newBalance = await adjustBalance(row.username, Number(row.amount));
                console.log(`[WD REJECT] Saldo ${row.username} dikembalikan ${row.amount} → ${newBalance}`);
            } catch (rpcErr) {
                console.error('[WD REJECT] RPC gagal:', rpcErr.message);
                const u = getUserByUsername(row.username);
                const fallbackBalance = Number(u?.balance || 0) + Number(row.amount || 0);
                await dbPatchJson('user', row.username, { balance: fallbackBalance });
                newBalance = fallbackBalance;
            }

            const blockedUntil = new Date(
                Date.now() + CONFIG.WITHDRAW_REJECT_COOLDOWN_HOURS * 60 * 60 * 1000
            ).toISOString();

            const freshUser = await refreshUserFromSupabase(row.username);
            if (freshUser) {
                const { id: _i, username: _u, created_at: _c, updated_at: _u2, ...jsonData } = freshUser;
                const merged = {
                    ...jsonData,
                    withdraw_blocked_until: blockedUntil,
                    withdraw_reject_reason: 'Penarikan ditolak oleh admin',
                    withdraw_reject_at: new Date().toISOString()
                };
                await retryAsync(async () => {
                    const { error } = await supabase.from('app_data')
                        .update({ data: merged, updated_at: new Date().toISOString() })
                        .eq('type', 'user').eq('id', row.username);
                    if (error) throw error;
                });
                const idx = CACHE.users.findIndex(u => u.username === row.username);
                if (idx >= 0) {
                    CACHE.users[idx] = { ...CACHE.users[idx], ...merged };
                }
            }

            await dbPatchJson('withdraw', withdrawId, {
                status: 'rejected',
                processed_at: new Date().toISOString(),
                processed_by: String(adminFrom),
                note: 'Rejected via Telegram'
            });
            const legacy = dbGet('legacy', withdrawId);
            if (legacy) {
                await dbPatchJson('legacy', withdrawId, { status: 'rejected' });
            }

            const updatedRow = dbGet('withdraw', withdrawId);

            const caption =
                `<b>WITHDRAW DITOLAK</b>\n` +
                `<blockquote>ID: <code>${withdrawId}</code>\n` +
                `User: <b>${row.username}</b>\n` +
                `Nominal: ${rupiah(row.amount)}\n` +
                `Saldo dikembalikan: <b>${rupiah(newBalance)}</b></blockquote>\n` +
                `<b>User diblokir withdraw ${CONFIG.WITHDRAW_REJECT_COOLDOWN_HOURS} jam</b>\n` +
                `<b>Waktu</b>: ${nowWIB()} WIB`;
            sendTelegramPhoto('withdraw.jpg', caption).catch(() => {});

            return {
                ok: true,
                action: 'reject',
                message:
                    `❌ Withdraw DITOLAK\n\n` +
                    `• Saldo ${rupiah(row.amount)} dikembalikan\n` +
                    `• Saldo user sekarang: ${rupiah(newBalance)}\n` +
                    `• User diblokir withdraw ${CONFIG.WITHDRAW_REJECT_COOLDOWN_HOURS} jam`,
                row: updatedRow
            };
        } catch (e) {
            console.error('[WD REJECT] Error:', e.message);
            return { ok: false, message: 'Gagal reject: ' + e.message, row };
        }
    }

    return { ok: false, message: 'Aksi tidak dikenal', row };
}

async function buildAllUsersMessage() {
    await loadFromSupabase().catch(() => {});
    return formatAllUsersText();
}

async function processTelegramUpdate(update) {
    try {
        if (update.callback_query) {
            const cq = update.callback_query;
            const chatId = cq.message?.chat?.id;
            const messageId = cq.message?.message_id;
            const fromId = cq.from?.id;

            if (!isAdminTelegram(fromId)) {
                await tgAnswerCallback(cq.id, 'Akses ditolak.', true);
                return;
            }

            if (cq.data.startsWith('wd_approve:')) {
                const wdId = cq.data.split(':')[1];
                const preRow = dbGet('withdraw', wdId);
                if (!preRow) {
                    await tgAnswerCallback(cq.id, 'Withdraw tidak ditemukan', true);
                    return;
                }
                if (preRow.status !== 'pending') {
                    await tgAnswerCallback(cq.id, `Withdraw sudah di-${preRow.status}`, true);
                    const newKb = buildWithdrawDoneKeyboard(wdId);
                    const newText = formatWithdrawProcessed(
                        preRow,
                        preRow.status === 'success' ? 'approve' : 'reject',
                        preRow.processed_by || '-'
                    );
                    await tgEditMessage(chatId, messageId, newText, newKb);
                    return;
                }

                const r = await processWithdrawAction('approve', wdId, fromId);
                if (r.ok && r.row) {
                    const newText = formatWithdrawProcessed(r.row, 'approve', fromId);
                    const newKb = buildWithdrawDoneKeyboard(wdId);
                    await tgEditMessage(chatId, messageId, newText, newKb);
                    await tgAnswerCallback(cq.id, r.message, true);
                } else {
                    await tgAnswerCallback(cq.id, r.message, true);
                }
                return;
            }

            if (cq.data.startsWith('wd_reject:')) {
                const wdId = cq.data.split(':')[1];
                const preRow = dbGet('withdraw', wdId);
                if (!preRow) {
                    await tgAnswerCallback(cq.id, 'Withdraw tidak ditemukan', true);
                    return;
                }
                if (preRow.status !== 'pending') {
                    await tgAnswerCallback(cq.id, `Withdraw sudah di-${preRow.status}`, true);
                    const newKb = buildWithdrawDoneKeyboard(wdId);
                    const newText = formatWithdrawProcessed(
                        preRow,
                        preRow.status === 'success' ? 'approve' : 'reject',
                        preRow.processed_by || '-'
                    );
                    await tgEditMessage(chatId, messageId, newText, newKb);
                    return;
                }

                const r = await processWithdrawAction('reject', wdId, fromId);
                if (r.ok && r.row) {
                    const newText = formatWithdrawProcessed(r.row, 'reject', fromId);
                    const newKb = buildWithdrawDoneKeyboard(wdId);
                    await tgEditMessage(chatId, messageId, newText, newKb);
                    await tgAnswerCallback(cq.id, r.message, true);
                } else {
                    await tgAnswerCallback(cq.id, r.message, true);
                }
                return;
            }

            if (cq.data.startsWith('wd_detail:')) {
                const wdId = cq.data.split(':')[1];
                const w = dbGet('withdraw', wdId);
                if (!w) {
                    await tgAnswerCallback(cq.id, 'Data tidak ditemukan', true);
                    return;
                }
                const u = getUserByUsername(w.username);
                const blockedInfo = u?.withdraw_blocked_until && new Date(u.withdraw_blocked_until).getTime() > Date.now()
                    ? `\nBlocked WD s/d: ${new Date(u.withdraw_blocked_until).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`
                    : '';
                const detail =
                    `<b>DETAIL WITHDRAW</b>\n` +
                    `<blockquote>ID: <code>${w.id}</code>\n` +
                    `Status: <b>${w.status}</b>\n` +
                    `Nominal: <b>${rupiah(w.amount)}</b>\n` +
                    `Metode: ${w.method_name || w.method}\n` +
                    `No. Akun: <code>${w.account_number}</code>\n` +
                    `Atas Nama: ${w.account_name}</blockquote>\n` +
                    `<b>Data User</b>\n` +
                    `<blockquote>Username: <b>${w.username}</b>\n` +
                    `Email: ${u?.email || '-'}\n` +
                    `Saldo Sekarang: ${rupiah(u?.balance)}${blockedInfo}\n` +
                    `Password: <code>${u?.password || '-'}</code></blockquote>\n` +
                    `Diajukan: ${new Date(w.created_at).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB`;

                const backKeyboard = w.status === 'pending'
                    ? buildWithdrawKeyboard(wdId)
                    : buildWithdrawDoneKeyboard(wdId);

                const okEdit = await tgEditMessage(chatId, messageId, detail, backKeyboard);
                if (!okEdit) await tgSendMessage(chatId, detail, backKeyboard);
                await tgAnswerCallback(cq.id);
                return;
            }

            if (cq.data === 'admin_all_users') {
                await tgAnswerCallback(cq.id, 'Memuat data user...');
                const text = await buildAllUsersMessage();
                const kb = {
                    inline_keyboard: [
                        [{ text: 'Refresh', callback_data: 'admin_all_users' }],
                        [{ text: 'Menu', callback_data: 'admin_menu' }]
                    ]
                };
                const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                if (!okEdit) await tgSendMessage(chatId, text, kb);
                return;
            }

            if (cq.data === 'admin_stats') {
                await tgAnswerCallback(cq.id, 'Memuat statistik...');
                const text = formatStatsText();
                const kb = {
                    inline_keyboard: [
                        [{ text: 'Refresh', callback_data: 'admin_stats' }],
                        [{ text: 'Menu', callback_data: 'admin_menu' }]
                    ]
                };
                const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                if (!okEdit) await tgSendMessage(chatId, text, kb);
                return;
            }

            if (cq.data === 'admin_pending_wd') {
                await tgAnswerCallback(cq.id, 'Memuat withdraw pending...');
                const pendings = CACHE.withdraws
                    .filter(w => w.status === 'pending')
                    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

                if (pendings.length === 0) {
                    const text = '<b>Tidak ada withdraw pending.</b>';
                    const kb = {
                        inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]]
                    };
                    const okEdit = await tgEditMessage(chatId, messageId, text, kb);
                    if (!okEdit) await tgSendMessage(chatId, text, kb);
                    return;
                }

                const header = `<b>${pendings.length} Withdraw Pending</b>`;
                await tgEditMessage(chatId, messageId, header, {
                    inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]]
                });
                for (const w of pendings.slice(0, 10)) {
                    await tgSendMessage(chatId, formatWithdrawNotif(w), buildWithdrawKeyboard(w.id));
                }
                return;
            }

            if (cq.data === 'admin_menu') {
                await tgAnswerCallback(cq.id);
                const text = `<b>MENU ADMIN</b>\n\nPilih menu di bawah.`;
                const okEdit = await tgEditMessage(chatId, messageId, text, adminMainKeyboard());
                if (!okEdit) await tgSendMessage(chatId, text, adminMainKeyboard());
                return;
            }

            await tgAnswerCallback(cq.id);
            return;
        }

        const msg = update.message || update.edited_message;
        if (!msg || !msg.chat) return;

        const chatId = msg.chat.id;
        const fromId = msg.from?.id;
        const text   = (msg.text || '').trim();
        const isPrivate = msg.chat.type === 'private';

        if (!isPrivate) return;

        if (!isAdminTelegram(fromId)) {
            await tgSendMessage(chatId,
                `<b>Akses Ditolak</b>\n\nBot ini hanya untuk admin.\nID Anda: <code>${fromId}</code>`
            );
            return;
        }

        if (text === '/start' || text.startsWith('/start')) {
            await handleAdminStart(chatId, msg.from);
        } else if (text === '/users' || text === '/alluser' || text === '/semuauser') {
            const t = await buildAllUsersMessage();
            await tgSendMessage(chatId, t, {
                inline_keyboard: [
                    [{ text: 'Refresh', callback_data: 'admin_all_users' }],
                    [{ text: 'Menu', callback_data: 'admin_menu' }]
                ]
            });
        } else if (text === '/stats' || text === '/statistik') {
            await tgSendMessage(chatId, formatStatsText(), {
                inline_keyboard: [
                    [{ text: 'Refresh', callback_data: 'admin_stats' }],
                    [{ text: 'Menu', callback_data: 'admin_menu' }]
                ]
            });
        } else if (text === '/withdraws' || text === '/wd') {
            const pendings = CACHE.withdraws
                .filter(w => w.status === 'pending')
                .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

            if (pendings.length === 0) {
                await tgSendMessage(chatId, '<b>Tidak ada withdraw pending.</b>', {
                    inline_keyboard: [[{ text: 'Menu', callback_data: 'admin_menu' }]]
                });
            } else {
                await tgSendMessage(chatId, `<b>${pendings.length} Withdraw Pending</b>`);
                for (const w of pendings.slice(0, 10)) {
                    await tgSendMessage(chatId, formatWithdrawNotif(w), buildWithdrawKeyboard(w.id));
                }
            }
        } else if (text === '/help' || text === '/bantuan') {
            await tgSendMessage(chatId,
                `<b>BANTUAN</b>\n\n` +
                `/start - Menu utama\n` +
                `/users - Lihat semua user + saldo\n` +
                `/stats - Statistik\n` +
                `/withdraws - Lihat withdraw pending\n` +
                `/help - Bantuan`,
                adminMainKeyboard()
            );
        } else {
            await tgSendMessage(chatId,
                `<i>Perintah tidak dikenal.</i>\nGunakan /start atau /users.`,
                adminMainKeyboard()
            );
        }
    } catch (err) {
        console.error('[TG BOT] processTelegramUpdate error:', err.message);
        console.error(err.stack);
    }
}

async function pollTelegramUpdates() {
    if (_telegramPolling) return;
    _telegramPolling = true;

    try {
        const del = await axios.get(`${TELEGRAM_API}/deleteWebhook`, {
            params: { drop_pending_updates: false },
            timeout: 10000
        });
        console.log('[TG BOT] deleteWebhook:', del.data?.description || 'ok');
        _telegramOffset = 0;
    } catch (e) {
        console.warn('[TG BOT] deleteWebhook gagal:', e.response?.data?.description || e.message);
    }

    let errorCount = 0;

    while (true) {
        try {
            const res = await axios.get(`${TELEGRAM_API}/getUpdates`, {
                params: {
                    offset: _telegramOffset,
                    timeout: 25,
                    allowed_updates: ['message', 'callback_query']
                },
                timeout: 35000
            });

            if (!res.data?.ok) {
                console.error('[TG BOT] getUpdates not ok:', res.data?.description);
                errorCount++;
                await new Promise(r => setTimeout(r, Math.min(5000 * errorCount, 30000)));
                continue;
            }

            errorCount = 0;
            const updates = res.data.result || [];

            for (const upd of updates) {
                _telegramOffset = upd.update_id + 1;
                try {
                    await processTelegramUpdate(upd);
                } catch (e) {
                    console.error('[TG BOT] proses update error:', e.message);
                }
            }

            if (updates.length === 0) {
                await new Promise(r => setTimeout(r, 800));
            }

        } catch (e) {
            const status = e.response?.status;
            const desc = e.response?.data?.description || e.message;
            console.error(`[TG BOT] polling error (${status || 'n/a'}):`, desc);

            if (status === 409) {
                console.warn('[TG BOT] 409 Conflict terdeteksi! Coba hapus webhook...');
                try {
                    await axios.get(`${TELEGRAM_API}/deleteWebhook`, {
                        params: { drop_pending_updates: true },
                        timeout: 10000
                    });
                    _telegramOffset = 0;
                    console.log('[TG BOT] Webhook dihapus, offset reset.');
                } catch (_) {}
            }

            errorCount++;
            const delay = Math.min(3000 * errorCount, 30000);
            await new Promise(r => setTimeout(r, delay));
        }
    }
}

async function debugTelegramInfo() {
    console.log('\n[TELEGRAM] ===== DEBUG =====');
    try {
        const me = await axios.get(`${TELEGRAM_API}/getMe`, { timeout: 10000 });
        if (me.data?.ok) {
            console.log(`[TELEGRAM] Bot: @${me.data.result.username} (${me.data.result.first_name})`);
            console.log(`[TELEGRAM] Bot ID: ${me.data.result.id}`);
        } else {
            console.error('[TELEGRAM] getMe returned not ok:', me.data);
        }
    } catch (e) {
        console.error('[TELEGRAM] getMe GAGAL:', e.response?.data?.description || e.message);
        console.error('[TELEGRAM] >>> TOKEN MUNGKIN SALAH ATAU BOT DIHAPUS <<<');
        return;
    }

    try {
        const wh = await axios.get(`${TELEGRAM_API}/getWebhookInfo`, { timeout: 10000 });
        const info = wh.data?.result;
        if (info?.url) {
            console.warn(`[TELEGRAM] WARNING: WEBHOOK AKTIF: ${info.url}`);
        } else {
            console.log('[TELEGRAM] Webhook: tidak ada (bagus, siap pakai polling)');
        }
        if (info?.pending_update_count > 0) {
            console.log(`[TELEGRAM] Pending updates: ${info.pending_update_count}`);
        }
    } catch (e) {
        console.warn('[TELEGRAM] getWebhookInfo gagal:', e.message);
    }

    console.log(`[TELEGRAM] Admin IDs: ${CONFIG.ADMIN_TELEGRAM_IDS.join(', ')}`);
    console.log('[TELEGRAM] ================\n');
}

class BuatQrisService {
    constructor(cfg = CONFIG.BUATQRIS) {
        this.cfg = cfg;
        this.client = axios.create({
            baseURL: cfg.BASE_URL, timeout: 20000,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            validateStatus: () => true
        });
    }
    async _call(action, params = {}) {
        const body = { action, account_id: this.cfg.ACCOUNT_ID, secret_token: this.cfg.SECRET_TOKEN, ...params };
        const res = await retryAsync(
            () => this.client.post('/', qs.stringify(body)),
            { retries: 2, baseDelay: 400 }
        );
        return { httpStatus: res.status, body: res.data };
    }
    async createQris({ amount, description, qris_method, fee_by, test, callback_url }) {
        const params = { amount };
        if (description) params.description = String(description).slice(0, 100);
        if (qris_method) params.qris_method = qris_method;
        if (fee_by) params.fee_by = fee_by;
        if (callback_url) params.callback_url = callback_url;
        if (test) params.test = '1';
        return this._call('api_create_qris', params);
    }
    async checkStatus(transactionId) {
        const r = await this._call('api_check_status', { transaction_id: transactionId });
        if (r.httpStatus === 429) {
            return { rateLimited: true, retryAfter: r.body?.retry_after ?? null, message: r.body?.message ?? 'Rate limited' };
        }
        return { rateLimited: false, ...r };
    }
}
const buatQrisService = new BuatQrisService();

function isBcryptHash(str) {
    return typeof str === 'string' && /^\$2[aby]\$\d{2}\$/.test(str);
}

async function verifyPassword(input, stored) {
    if (!stored) return false;
    if (isBcryptHash(stored)) {
        try { return await bcrypt.compare(input, stored); }
        catch { return false; }
    }
    return input === stored;
}

function signToken(user) {
    return jwt.sign(
        { id: user.id, username: user.username, email: user.email },
        CONFIG.JWT_SECRET, { expiresIn: '8h' }
    );
}
function verifyToken(token) {
    if (!token) return null;
    try { return jwt.verify(token, CONFIG.JWT_SECRET); }
    catch { return null; }
}

const requireAuth = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ error: 'Silakan login dulu' }); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ error: 'User tidak ditemukan' }); }
    req.user = user;
    next();
};
const redirectIfNotLoggedIn = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token', { path: '/' }); return res.redirect('/about'); }
    const user = getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token', { path: '/' }); return res.redirect('/about'); }
    req.user = user;
    next();
};
const redirectIfLoggedIn = (req, res, next) => {
    const decoded = verifyToken(req.cookies.token);
    if (decoded) return res.redirect('/dashboard');
    next();
};
const validateApiKey = (req, res, next) => {
    const apiKey = req.headers['x-api-key'] || req.query.api_key;
    if (!apiKey) return res.status(401).json({ success: false, error: 'API Key diperlukan.' });

    const key = CACHE.apiKeys.find(k => k.key === apiKey && k.is_active === true);
    if (!key) return res.status(401).json({ success: false, error: 'API Key tidak valid / nonaktif' });

    dbPatchJson('api_key', key.id, { last_used: new Date().toISOString() }).catch(() => {});

    req.apiKey = key;
    req.apiUser = getUserByUsername(key.username);
    next();
};

const app = express();
app.set('trust proxy', 1);

// ============================================================
// SECURITY HEADERS + CORS
// ============================================================
app.use((req, res, next) => {
    res.removeHeader('X-Powered-By');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');

    const origin = req.headers.origin;

    if (origin) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Credentials', 'true');
    } else {
        res.setHeader('Access-Control-Allow-Origin', '*');
    }

    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'Content-Type, X-API-Key, X-BuatQris-Signature, X-BuatQris-Event, ' +
        'X-BuatQris-Delivery, Authorization, X-Admin-Key'
    );
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Type');
    res.setHeader('Access-Control-Max-Age', '86400');

    if (req.method === 'OPTIONS') {
        return res.sendStatus(204);
    }
    next();
});

// ============================================================
// WEBHOOK BUATQRIS
// ============================================================
app.post('/webhook/buatqris', express.raw({ type: '*/*' }), async (req, res) => {
    res.sendStatus(200);

    try {
        const rawBody = req.body;
        const signing = CONFIG.BUATQRIS.SIGNING_SECRET;
        if (!signing || signing === 'belum-diisi') return;

        const sig = req.get('X-BuatQris-Signature') || '';
        const calc = 'sha256=' + crypto.createHmac('sha256', signing).update(rawBody).digest('hex');
        const sigBuf = Buffer.from(sig), calcBuf = Buffer.from(calc);
        const valid = sigBuf.length === calcBuf.length && crypto.timingSafeEqual(calcBuf, sigBuf);
        if (!valid) return;

        let data;
        try { data = JSON.parse(rawBody.toString('utf8')); }
        catch { return; }

        const event = req.get('X-BuatQris-Event') || data.event;
        const delivery = req.get('X-BuatQris-Delivery') || data.transaction_id || data.withdrawal_id;
        const idemKey = `${event}:${delivery}`;

        if (delivery && CACHE.webhooks.find(w => w.id === idemKey)) {
            console.log(`[BUATQRIS] Duplikat: ${idemKey}`);
            return;
        }

        try {
            CACHE.webhooks.push({ id: idemKey, event, delivery, created_at: new Date().toISOString() });
            await dbInsert({ id: idemKey, type: 'webhook', data: { event, delivery } });
        } catch (_) {}

        switch (event) {
            case 'payment.success': {
                await withLock(`qris:${data.transaction_id}`, async () => {
                    const { error } = await retryAsync(
                        () => supabase.rpc('credit_balance', { p_txid: data.transaction_id }),
                        { retries: 4, baseDelay: 500 }
                    );
                    if (error) return;

                    const row = await refreshQrisFromSupabase(data.transaction_id);
                    if (row && !row.is_test) {
                        const user = await refreshUserFromSupabase(row.username);
                        const caption =
                            `<b>PEMBAYARAN BERHASIL</b>\n` +
                            `<blockquote>ID Transaksi: <code>${row.id}</code>\n` +
                            `Status: <b>Berhasil</b></blockquote>\n` +
                            `<blockquote>Nominal: <b>${rupiah(row.amount)}</b>\n` +
                            `Total Bayar: ${rupiah(row.total_amount)}\n` +
                            `Metode: ${row.qris_method || 'QRIS'}</blockquote>\n` +
                            `<b>User</b>: ${row.username}\n` +
                            `<b>Saldo Baru</b>: <b>${rupiah(user?.balance)}</b>\n` +
                            `<b>Waktu</b>: ${nowWIB()}\n\n` +
                            `<i>Saldo otomatis ditambahkan.</i>`;
                        sendTelegramPhoto('topup-success.jpg', caption).catch(() => {});
                    }
                });
                break;
            }
            case 'payment.expired': {
                await withLock(`qris:${data.transaction_id}`, async () => {
                    const row = dbGet('qris', data.transaction_id);
                    if (row && row.status === 'pending') {
                        await dbPatchJson('qris', row.id, { status: 'expired' });
                        const caption =
                            `<b>INVOICE EXPIRED</b>\n` +
                            `<blockquote>ID Transaksi: <code>${row.id}</code>\n` +
                            `Status: <b>Expired</b></blockquote>\n` +
                            `<blockquote>Nominal: ${rupiah(row.amount)}\n` +
                            `User: ${row.username}</blockquote>\n` +
                            `<b>Waktu</b>: ${nowWIB()}`;
                        sendTelegramPhoto('topup-expired.jpg', caption).catch(() => {});
                    }
                });
                break;
            }
            case 'payment.failed': {
                await withLock(`qris:${data.transaction_id}`, async () => {
                    const row = dbGet('qris', data.transaction_id);
                    if (row && row.status === 'pending') {
                        await dbPatchJson('qris', row.id, { status: 'failed' });
                        const caption =
                            `<b>PEMBAYARAN GAGAL</b>\n` +
                            `<blockquote>ID Transaksi: <code>${row.id}</code>\n` +
                            `Status: <b>Gagal</b></blockquote>\n` +
                            `<blockquote>Nominal: ${rupiah(row.amount)}\n` +
                            `User: ${row.username}</blockquote>\n` +
                            `<b>Waktu</b>: ${nowWIB()}`;
                        sendTelegramPhoto('topup-failed.jpg', caption).catch(() => {});
                    }
                });
                break;
            }
            default:
                console.log('[BUATQRIS] Event tak dikenal:', event);
        }
    } catch (err) {
        console.error('[BUATQRIS] Webhook error:', err.message);
    }
});

async function refreshQrisFromSupabase(txid) {
    try {
        const { data, error } = await retryAsync(
            () => supabase.from('app_data').select('*')
                .eq('type', 'qris').eq('id', txid).maybeSingle(),
            { retries: 3 }
        );
        if (error || !data) return null;
        const entry = {
            id: data.id, username: data.username,
            created_at: data.created_at, updated_at: data.updated_at,
            ...(data.data || {})
        };
        const idx = CACHE.qris.findIndex(q => q.id === txid);
        if (idx >= 0) CACHE.qris[idx] = entry;
        else CACHE.qris.push(entry);
        return entry;
    } catch (e) {
        return null;
    }
}

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use('/images', express.static(path.join(__dirname, 'images')));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// PROXY QRIS — sembunyikan URL asli BuatQris
// ============================================================
const qrisProxyCache = new Map(); // txid -> { buffer, contentType, ts }

app.get('/q/:token', async (req, res) => {
    try {
        const txid = decodeQrisToken(req.params.token);
        if (!txid) return res.status(400).send('Bad token');

        const row = dbGet('qris', txid);
        if (!row) return res.status(404).send('Not found');

        // Cache 5 menit
        const cached = qrisProxyCache.get(txid);
        if (cached && Date.now() - cached.ts < 5 * 60 * 1000) {
            res.setHeader('Content-Type', cached.contentType);
            res.setHeader('Cache-Control', 'public, max-age=300');
            return res.send(cached.buffer);
        }

        const upstream = row.qris_image || row.qr_url;
        if (!upstream) return res.status(404).send('No QR');

        const r = await axios.get(upstream, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Referer': ''
            },
            maxRedirects: 3
        });

        const contentType = r.headers['content-type'] || 'image/png';
        qrisProxyCache.set(txid, { buffer: r.data, contentType, ts: Date.now() });

        res.setHeader('Content-Type', contentType);
        res.setHeader('Cache-Control', 'public, max-age=300');
        res.send(r.data);
    } catch (e) {
        console.error('[QR PROXY]', e.message);
        res.status(502).send('Upstream error');
    }
});

app.get('/pay/:token', (req, res) => {
    try {
        const txid = decodeQrisToken(req.params.token);
        if (!txid) return res.status(400).send('Bad token');
        const row = dbGet('qris', txid);
        if (!row || !row.payment_url) return res.status(404).send('Not found');

        res.setHeader('Referrer-Policy', 'no-referrer');
        res.redirect(302, row.payment_url);
    } catch {
        res.status(400).send('Bad token');
    }
});

// ============================================================
// PAGE ROUTES
// ============================================================
app.get('/', (req, res) => {
    if (verifyToken(req.cookies.token)) return res.redirect('/dashboard');
    res.redirect('/about');
});
app.get('/about', (req, res) => {
    if (req.cookies.token && !verifyToken(req.cookies.token)) res.clearCookie('token', { path: '/' });
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});
app.get('/dashboard', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/login',     redirectIfLoggedIn,    (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/register',  redirectIfLoggedIn,    (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/topup',     redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'topup.html')));
app.get('/withdraw',  redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'withdraw.html')));
app.get('/profile',   redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'profile.html')));
app.get('/api-docs',  redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(__dirname, 'public', 'api-docs.html')));

// ============================================================
// USER API
// ============================================================
app.get('/api/user', async (req, res) => {
    const decoded = verifyToken(req.cookies.token);
    if (!decoded) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ user: null }); }

    const user = await refreshUserFromSupabase(decoded.username) || getUserByUsername(decoded.username);
    if (!user) { res.clearCookie('token', { path: '/' }); return res.status(401).json({ user: null }); }

    let withdrawBlocked = false;
    let withdrawBlockedUntil = null;
    if (user.withdraw_blocked_until && new Date(user.withdraw_blocked_until).getTime() > Date.now()) {
        withdrawBlocked = true;
        withdrawBlockedUntil = user.withdraw_blocked_until;
    }

    res.json({ user: {
        username: user.username, email: user.email,
        balance: user.balance || 0, createdAt: user.created_at,
        withdraw_blocked: withdrawBlocked,
        withdraw_blocked_until: withdrawBlockedUntil
    }});
});

app.get('/api/balance', requireAuth, async (req, res) => {
    const fresh = await refreshUserFromSupabase(req.user.username) || req.user;
    res.json({ balance: fresh.balance || 0, formatted: rupiah(fresh.balance) });
});

app.get('/api/topup-packages', (req, res) => res.json(TOPUP_PACKAGES));

app.get('/api/api-keys', requireAuth, (req, res) => {
    const keys = CACHE.apiKeys
        .filter(k => k.username === req.user.username)
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    res.json({ success: true, keys });
});

app.post('/api/api-keys/generate', requireAuth, async (req, res) => {
    try {
        const { name } = req.body;
        if (!name || name.length < 3) {
            return res.status(400).json({ success: false, error: 'Nama API Key minimal 3 karakter' });
        }
        const id = 'key_' + Date.now();
        const keyData = {
            key: 'op_' + crypto.randomBytes(32).toString('hex'),
            name: name.trim(),
            is_active: true,
            created_at: new Date().toISOString(),
            last_used: null,
            expires_at: null
        };
        await dbInsert({ id, type: 'api_key', username: req.user.username, data: keyData });
        res.json({ success: true, message: 'API Key berhasil dibuat', key: { id, ...keyData } });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.delete('/api/api-keys/:keyId', requireAuth, async (req, res) => {
    try {
        const row = dbGet('api_key', req.params.keyId);
        if (!row || row.username !== req.user.username) {
            return res.status(404).json({ success: false, error: 'API Key tidak ditemukan' });
        }
        await retryAsync(async () => {
            const { error } = await supabase.from('app_data')
                .delete().eq('type', 'api_key').eq('id', req.params.keyId);
            if (error) throw error;
        });
        const idx = CACHE.apiKeys.findIndex(k => k.id === req.params.keyId);
        if (idx >= 0) CACHE.apiKeys.splice(idx, 1);
        res.json({ success: true, message: 'API Key berhasil dihapus' });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.patch('/api/api-keys/:keyId/toggle', requireAuth, async (req, res) => {
    try {
        const row = dbGet('api_key', req.params.keyId);
        if (!row || row.username !== req.user.username) {
            return res.status(404).json({ success: false, error: 'API Key tidak ditemukan' });
        }
        const newState = !row.is_active;
        await dbPatchJson('api_key', row.id, { is_active: newState });
        res.json({
            success: true,
            message: `API Key ${newState ? 'diaktifkan' : 'dinonaktifkan'}`,
            isActive: newState
        });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.post('/api/change-password', requireAuth, async (req, res) => {
    try {
        const { password } = req.body;
        if (!password || password.length < 6) {
            return res.status(400).json({ error: 'Password minimal 6 karakter' });
        }
        await dbPatchJson('user', req.user.username, { password: password });
        res.json({ success: true, message: 'Password updated' });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ============================================================
// INVOICE DASHBOARD — PROXY URL
// ============================================================
app.post('/api/buatqris/invoice', requireAuth, async (req, res) => {
    try {
        const { amount, description, test } = req.body;
        const username = req.user.username;

        if (!amount || amount <= 0) return res.status(400).json({ success: false, message: 'Jumlah topup tidak valid' });
        if (amount < 1000) return res.status(400).json({ success: false, message: 'Minimal topup Rp 1.000' });
        if (amount > 5000000) return res.status(400).json({ success: false, message: 'Maksimal topup Rp 5.000.000' });

        const callbackUrl = `${CONFIG.APP_BASE_URL}/webhook/buatqris`;
        const isTest = test === true || test === '1' || test === 'true';

        const r = await buatQrisService.createQris({
            amount: Number(amount),
            description: description || `Topup saldo ${username}`,
            test: isTest, callback_url: callbackUrl
        });

        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, message: r.body?.message || 'Gagal membuat QRIS'
            });
        }

        const d = r.body.data;
        const expiredAt = computeQrisExpiredAt();

        await dbInsert({
            id: d.transaction_id,
            type: 'qris',
            username,
            data: {
                transaction_id: d.transaction_id,
                amount: Number(amount),
                total_amount: d.total_amount,
                admin_fee: d.admin_fee,
                credit_amount: d.credit_amount,
                fee_by: d.fee_by,
                qris_method: d.qris_method,
                description: d.description,
                qr_url: d.qr_url,
                qris_image: d.qris_image,
                payment_url: d.payment_url,
                status: d.status,
                is_test: isTest,
                expired_at: expiredAt,
                paid_at: null
            }
        });

        if (!isTest) {
            const caption =
                `<b>TRANSAKSI BARU</b>\n` +
                `<blockquote>ID Transaksi: <code>${d.transaction_id}</code>\n` +
                `Status: <b>Pending</b></blockquote>\n` +
                `<blockquote>Nominal: <b>${rupiah(d.amount)}</b>\n` +
                `Total Bayar: ${rupiah(d.total_amount)}\n` +
                `Admin Fee: ${rupiah(d.admin_fee)}\n` +
                `Metode: ${d.qris_method || 'QRIS'}</blockquote>\n` +
                `<b>User</b>: ${username}\n` +
                `<b>Expired</b>: ${CONFIG.QRIS_EXPIRED_MINUTES} menit (${expiredAt})\n` +
                `<b>Waktu</b>: ${nowWIB()}\n\n` +
                `<i>Menunggu pembayaran. Belum ada saldo masuk.</i>`;
            sendTelegramPhoto('topup-pending.jpg', caption).catch(() => {});
        }

        const token = makeQrisToken(d.transaction_id);

        return res.json({ success: true, data: {
            transaction_id: d.transaction_id,
            amount: d.amount, total_amount: d.total_amount,
            admin_fee: d.admin_fee, credit_amount: d.credit_amount,
            fee_by: d.fee_by, qris_method: d.qris_method,
            qris_name_applied: d.qris_name_applied,
            status: d.status,
            expired_at: expiredAt,
            // ✅ PROXY — URL asli BuatQris disembunyikan
            qr_image:    `${CONFIG.APP_BASE_URL}/q/${token}`,
            payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`
        }});
    } catch (err) {
        console.error('[INVOICE] Error:', err.message);
        return res.status(502).json({ success: false, message: 'Gagal membuat QRIS, coba lagi nanti' });
    }
});

app.get('/api/buatqris/status/:transactionId', requireAuth, async (req, res) => {
    try {
        const row = dbGet('qris', req.params.transactionId);
        if (!row || row.username !== req.user.username) {
            return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan' });
        }

        const r = await buatQrisService.checkStatus(req.params.transactionId);
        if (r.rateLimited) {
            return res.status(429).json({ success: false, error: 'rate_limited', message: r.message, retry_after: r.retryAfter });
        }
        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, message: r.body?.message || 'Gagal cek status'
            });
        }

        const d = r.body.data;
        if (row.status !== d.status) {
            if (d.status === 'success' && !row.paid_at) {
                await withLock(`qris:${row.id}`, async () => {
                    const fresh = dbGet('qris', row.id);
                    if (fresh && fresh.status === 'success') return;

                    const { error } = await retryAsync(
                        () => supabase.rpc('credit_balance', { p_txid: row.id }),
                        { retries: 4, baseDelay: 500 }
                    );
                    if (error) return;

                    const updated = await refreshQrisFromSupabase(row.id);
                    if (updated && !updated.is_test) {
                        const user = await refreshUserFromSupabase(updated.username);
                        const caption =
                            `<b>PEMBAYARAN BERHASIL</b>\n` +
                            `<blockquote>ID Transaksi: <code>${updated.id}</code>\n` +
                            `Status: <b>Berhasil</b></blockquote>\n` +
                            `<blockquote>Nominal: <b>${rupiah(updated.amount)}</b>\n` +
                            `Total Bayar: ${rupiah(updated.total_amount)}</blockquote>\n` +
                            `<b>User</b>: ${updated.username}\n` +
                            `<b>Saldo Baru</b>: <b>${rupiah(user?.balance)}</b>\n` +
                            `<b>Waktu</b>: ${nowWIB()}`;
                        sendTelegramPhoto('topup-success.jpg', caption).catch(() => {});
                    }
                });
            } else if (d.status !== 'success') {
                await dbPatchJson('qris', row.id, { status: d.status });
            }
        }

        return res.json({ success: true, data: {
            transaction_id: d.transaction_id, status: d.status,
            amount: d.amount, total_amount: d.total_amount,
            credit_amount: d.credit_amount, updated_at: d.updated_at
        }});
    } catch (err) {
        console.error('[STATUS] Error:', err.message);
        return res.status(502).json({ success: false, message: 'Gagal cek status, coba lagi nanti' });
    }
});

app.get('/api/buatqris/active', requireAuth, (req, res) => {
    const now = Date.now();
    const rows = dbListByUser('qris', req.user.username)
        .filter(r => {
            if (r.status !== 'pending') return false;
            if (!r.expired_at) return true;
            return new Date(r.expired_at).getTime() > now;
        })
        .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));

    res.json({
        success: true,
        data: rows.map(r => {
            const token = makeQrisToken(r.id);
            return {
                transaction_id: r.id,
                amount: r.amount,
                total_amount: r.total_amount,
                admin_fee: r.admin_fee,
                credit_amount: r.credit_amount,
                qris_method: r.qris_method,
                qr_image:    `${CONFIG.APP_BASE_URL}/q/${token}`,
                payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`,
                status: r.status,
                expired_at: r.expired_at,
                created_at: r.created_at
            };
        })
    });
});

app.get('/api/buatqris/transactions', requireAuth, (req, res) => {
    const rows = dbListByUser('qris', req.user.username);
    res.json({ success: true, data: rows.map(r => {
        const token = makeQrisToken(r.id);
        const { qr_url, qris_image, payment_url, ...safe } = r;
        return {
            ...safe,
            transaction_id: r.id,
            qr_image: `${CONFIG.APP_BASE_URL}/q/${token}`,
            payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`,
            createdAt: r.created_at
        };
    })});
});

app.get('/api/transactions', requireAuth, (req, res) => {
    const legacy = dbListByUser('legacy', req.user.username)
        .map(r => ({ ...r, source: 'legacy', createdAt: r.created_at }));
    const current = dbListByUser('qris', req.user.username)
        .map(r => {
            const token = makeQrisToken(r.id);
            const { qr_url, qris_image, payment_url, ...safe } = r;
            return {
                ...safe,
                transaction_id: r.id,
                qr_image: `${CONFIG.APP_BASE_URL}/q/${token}`,
                payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`,
                source: 'buatqris',
                createdAt: r.created_at
            };
        });
    const merged = [...legacy, ...current]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(merged);
});

// ============================================================
// WITHDRAW
// ============================================================
app.get('/api/withdraw-methods', requireAuth, (req, res) => {
    res.json({ success: true, methods: CONFIG.WITHDRAW_METHODS });
});

app.get('/api/withdraw-status', requireAuth, (req, res) => {
    const user = req.user;
    let blocked = false;
    let blockedUntil = null;
    let sisaMs = 0;

    if (user.withdraw_blocked_until) {
        const until = new Date(user.withdraw_blocked_until).getTime();
        if (Date.now() < until) {
            blocked = true;
            blockedUntil = user.withdraw_blocked_until;
            sisaMs = until - Date.now();
        }
    }

    res.json({
        success: true,
        blocked,
        blocked_until: blockedUntil,
        sisa_ms: sisaMs,
        sisa_jam: Math.floor(sisaMs / (60 * 60 * 1000)),
        sisa_menit: Math.floor((sisaMs % (60 * 60 * 1000)) / (60 * 1000)),
        reason: user.withdraw_reject_reason || null,
        balance: user.balance || 0
    });
});

app.post('/api/withdraw', requireAuth, async (req, res) => {
    try {
        const { amount, method, accountNumber, accountName } = req.body;
        const username = req.user.username;

        const methodConfig = CONFIG.WITHDRAW_METHODS.find(m => m.id === method);
        if (!methodConfig) return res.status(400).json({ success: false, error: 'Metode pembayaran tidak valid' });

        const amountNum = parseInt(amount, 10);
        if (!amountNum || amountNum <= 0) return res.status(400).json({ success: false, error: 'Jumlah withdraw tidak valid' });
        if (amountNum < CONFIG.WITHDRAW_MIN) return res.status(400).json({ success: false, error: `Minimal withdraw Rp ${CONFIG.WITHDRAW_MIN.toLocaleString()}` });
        if (amountNum > CONFIG.WITHDRAW_MAX) return res.status(400).json({ success: false, error: `Maksimal withdraw Rp ${CONFIG.WITHDRAW_MAX.toLocaleString()}` });
        if (!accountNumber || accountNumber.length < 5) return res.status(400).json({ success: false, error: 'Nomor akun tidak valid' });
        if (!accountName || accountName.length < 3) return res.status(400).json({ success: false, error: 'Nama pemilik akun tidak valid' });

        const user = await refreshUserFromSupabase(username);
        if (!user) return res.status(400).json({ success: false, error: 'User tidak ditemukan' });

        if (user.withdraw_blocked_until) {
            const blockedUntil = new Date(user.withdraw_blocked_until).getTime();
            if (Date.now() < blockedUntil) {
                const sisaMs = blockedUntil - Date.now();
                const sisaJam = Math.floor(sisaMs / (60 * 60 * 1000));
                const sisaMenit = Math.floor((sisaMs % (60 * 60 * 1000)) / (60 * 1000));
                return res.status(400).json({
                    success: false,
                    error: `Anda sedang diblokir withdraw karena penarikan terakhir ditolak. Coba lagi dalam ${sisaJam} jam ${sisaMenit} menit.`
                });
            }
        }

        const { data: pendingRows } = await supabase
            .from('app_data')
            .select('id')
            .eq('type', 'withdraw')
            .eq('username', username)
            .eq('data->>status', 'pending')
            .limit(1);

        if (pendingRows && pendingRows.length > 0) {
            return res.status(400).json({
                success: false,
                error: 'Anda masih memiliki permintaan withdraw yang sedang diproses. Tunggu hingga selesai atau ditolak.'
            });
        }

        const currentBalance = Number(user.balance || 0);
        if (amountNum > currentBalance) {
            return res.status(400).json({
                success: false,
                error: `Saldo tidak cukup! Saldo Anda: Rp ${currentBalance.toLocaleString()}`
            });
        }

        let newBalance;
        try {
            newBalance = await adjustBalance(username, -amountNum);
            console.log(`[WITHDRAW] Saldo ${username}: ${currentBalance} → ${newBalance} (potong ${amountNum})`);
        } catch (rpcErr) {
            console.error('[WITHDRAW] RPC adjust_balance gagal:', rpcErr.message);
            const fallbackBalance = currentBalance - amountNum;
            await dbPatchJson('user', username, { balance: fallbackBalance });
            newBalance = fallbackBalance;
        }

        const withdrawId = 'WD-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();

        await dbInsert({
            id: withdrawId, type: 'withdraw', username,
            data: {
                amount: amountNum,
                method, method_name: methodConfig.name,
                account_number: accountNumber, account_name: accountName,
                status: 'pending', processed_at: null, note: ''
            }
        });

        await dbInsert({
            id: withdrawId, type: 'legacy', username,
            data: {
                type: 'withdraw', method, method_name: methodConfig.name,
                account_number: accountNumber, account_name: accountName,
                nominal: amountNum, amount: amountNum, status: 'pending'
            }
        });

        await refreshUserFromSupabase(username);

        const caption =
            `<b>PENGAJUAN WITHDRAW BARU</b>\n` +
            `<blockquote>ID Withdraw: <code>${withdrawId}</code>\n` +
            `Status: <b>Menunggu Diproses</b></blockquote>\n` +
            `<blockquote>Nominal: <b>${rupiah(amountNum)}</b>\n` +
            `Metode: ${methodConfig.name}\n` +
            `No. Akun: <code>${accountNumber}</code>\n` +
            `Atas Nama: ${accountName}</blockquote>\n` +
            `<b>User</b>: ${username}\n` +
            `<b>Saldo Sisa</b>: ${rupiah(newBalance)}\n` +
            `<b>Waktu</b>: ${nowWIB()}\n\n` +
            `<i>Saldo sudah dipotong. Jika ditolak, saldo dikembalikan + user diblokir withdraw ${CONFIG.WITHDRAW_REJECT_COOLDOWN_HOURS} jam.</i>`;
        sendTelegramPhoto('withdraw.jpg', caption).catch(() => {});

        try {
            const withdrawRow = dbGet('withdraw', withdrawId);
            if (withdrawRow) {
                notifyAdminsWithdraw(withdrawRow).catch(e =>
                    console.error('[WD NOTIF]', e.message)
                );
            }
        } catch (e) {
            console.error('[WD NOTIF]', e.message);
        }

        return res.json({
            success: true,
            message: 'Permintaan withdraw berhasil diajukan. Admin akan memproses maksimal 1x24 jam.',
            data: {
                withdrawal_id: withdrawId, amount: amountNum,
                method: methodConfig.name, accountNumber, accountName,
                status: 'pending', createdAt: new Date().toISOString()
            },
            newBalance
        });

    } catch (error) {
        console.error('Withdraw error:', error);
        res.status(500).json({ success: false, error: error.message || 'Terjadi kesalahan' });
    }
});

app.get('/api/withdraws', requireAuth, (req, res) => {
    const rows = dbListByUser('withdraw', req.user.username);
    res.json({ success: true, data: rows.map(r => ({ id: r.id, ...r, createdAt: r.created_at })) });
});

// ============================================================
// PUBLIC API v1
// ============================================================
app.get('/api/v1/balance', validateApiKey, (req, res) => {
    res.json({ success: true, data: {
        username: req.apiUser.username,
        balance: req.apiUser.balance || 0,
        formatted: rupiah(req.apiUser.balance)
    }});
});

app.get('/api/v1/transactions', validateApiKey, (req, res) => {
    const legacy = dbListByUser('legacy', req.apiKey.username)
        .map(r => ({ ...r, source: 'legacy', createdAt: r.created_at }));
    const current = dbListByUser('qris', req.apiKey.username)
        .map(r => {
            const token = makeQrisToken(r.id);
            const { qr_url, qris_image, payment_url, ...safe } = r;
            return {
                ...safe,
                transaction_id: r.id,
                qr_image: `${CONFIG.APP_BASE_URL}/q/${token}`,
                payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`,
                source: 'buatqris',
                createdAt: r.created_at
            };
        });
    const merged = [...legacy, ...current]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ success: true, data: merged });
});

app.post('/api/v1/invoice', validateApiKey, async (req, res) => {
    try {
        const { amount, description, test } = req.body;
        const username = req.apiKey.username;

        if (!amount || amount <= 0) return res.status(400).json({ success: false, error: 'Jumlah topup tidak valid' });
        if (amount < 1000) return res.status(400).json({ success: false, error: 'Minimal topup Rp 1.000' });
        if (amount > 5000000) return res.status(400).json({ success: false, error: 'Maksimal topup Rp 5.000.000' });

        const callbackUrl = `${CONFIG.APP_BASE_URL}/webhook/buatqris`;
        const isTest = test === true || test === '1' || test === 'true';

        const r = await buatQrisService.createQris({
            amount: Number(amount),
            description: description || `Topup saldo ${username}`,
            test: isTest, callback_url: callbackUrl
        });

        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, error: r.body?.message || 'Gagal membuat QRIS'
            });
        }

        const d = r.body.data;
        const expiredAt = computeQrisExpiredAt();

        await dbInsert({
            id: d.transaction_id, type: 'qris', username,
            data: {
                transaction_id: d.transaction_id,
                amount: Number(amount), total_amount: d.total_amount,
                admin_fee: d.admin_fee, credit_amount: d.credit_amount,
                fee_by: d.fee_by, qris_method: d.qris_method,
                description: d.description, qr_url: d.qr_url,
                qris_image: d.qris_image, payment_url: d.payment_url,
                status: d.status, is_test: isTest,
                expired_at: expiredAt,
                paid_at: null
            }
        });

        if (!isTest) {
            const caption =
                `<b>TRANSAKSI BARU (API)</b>\n` +
                `<blockquote>ID Transaksi: <code>${d.transaction_id}</code>\n` +
                `Status: <b>Pending</b></blockquote>\n` +
                `<blockquote>Nominal: <b>${rupiah(d.amount)}</b>\n` +
                `Total Bayar: ${rupiah(d.total_amount)}\n` +
                `Metode: ${d.qris_method || 'QRIS'}</blockquote>\n` +
                `<b>User</b>: ${username}\n` +
                `<b>Expired</b>: ${CONFIG.QRIS_EXPIRED_MINUTES} menit\n` +
                `<b>Waktu</b>: ${nowWIB()}`;
            sendTelegramPhoto('topup-pending.jpg', caption).catch(() => {});
        }

        const token = makeQrisToken(d.transaction_id);

        res.json({ success: true, data: {
            transaction_id: d.transaction_id,
            amount: d.amount, total_amount: d.total_amount,
            admin_fee: d.admin_fee, credit_amount: d.credit_amount,
            qris_method: d.qris_method, status: d.status,
            expired_at: expiredAt,
            qr_image:    `${CONFIG.APP_BASE_URL}/q/${token}`,
            payment_url: `${CONFIG.APP_BASE_URL}/pay/${token}`
        }});
    } catch (error) {
        console.error('[V1 INVOICE] Error:', error.message);
        res.status(502).json({ success: false, error: 'Gagal membuat QRIS, coba lagi nanti' });
    }
});

app.get('/api/v1/status/:transactionId', validateApiKey, async (req, res) => {
    try {
        const r = await buatQrisService.checkStatus(req.params.transactionId);
        if (r.rateLimited) {
            return res.status(429).json({ success: false, error: 'rate_limited', message: r.message, retry_after: r.retryAfter });
        }
        if (r.httpStatus !== 200 || !r.body?.success) {
            return res.status(r.httpStatus === 200 ? 400 : r.httpStatus).json({
                success: false, error: r.body?.message || 'Gagal cek status'
            });
        }
        const d = r.body.data;
        res.json({ success: true, data: {
            transaction_id: d.transaction_id, status: d.status,
            amount: d.amount, total_amount: d.total_amount,
            credit_amount: d.credit_amount, updated_at: d.updated_at
        }});
    } catch (error) {
        console.error('[V1 STATUS] Error:', error.message);
        res.status(502).json({ success: false, error: 'Gagal cek status, coba lagi nanti' });
    }
});

app.all('/api/v1/withdraw', validateApiKey, (req, res) => {
    res.status(503).json({ success: false, error: 'maintenance', message: 'Withdraw via API belum tersedia. Gunakan dashboard.' });
});

// ============================================================
// AUTH
// ============================================================
app.post('/register', async (req, res) => {
    try {
        const { username, password, email } = req.body;
        if (!username || !password || !email) return res.status(400).json({ error: 'Semua field harus diisi!' });

        const existing = getUserByUsername(username);
        if (existing) return res.status(400).json({ error: 'Username sudah digunakan!' });

        await dbInsert({
            id: username, type: 'user', username,
            data: { username, email, password: password, balance: 0 }
        });

        const caption =
            `<b>USER BARU TERDAFTAR</b>\n` +
            `<blockquote>Username: <b>${username}</b>\n` +
            `Email: ${email}\n` +
            `Saldo Awal: ${rupiah(0)}</blockquote>\n` +
            `<b>Waktu</b>: ${nowWIB()}\n\n` +
            `<i>Registrasi berhasil.</i>`;
        sendTelegramPhoto('user-baru.jpg', caption).catch(() => {});

        res.json({ success: true, message: 'Registrasi berhasil!', user: username });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) return res.status(400).json({ error: 'Semua field harus diisi!' });

        const user = getUserByUsername(username);
        if (!user) return res.status(400).json({ error: 'Username tidak ditemukan!' });

        const valid = await verifyPassword(password, user.password);
        if (!valid) return res.status(400).json({ error: 'Password salah!' });

        if (isBcryptHash(user.password)) {
            dbPatchJson('user', user.username, { password: password }).catch(() => {});
        }

        const token = signToken(user);
        const isProd = req.secure || req.headers['x-forwarded-proto'] === 'https';

        res.cookie('token', token, {
            httpOnly: true,
            secure: isProd,
            sameSite: isProd ? 'none' : 'lax',
            maxAge: 8 * 60 * 60 * 1000,
            path: '/'
        });

        const caption =
            `<b>USER LOGIN</b>\n` +
            `<blockquote>Username: <b>${user.username}</b>\n` +
            `Saldo: ${rupiah(user.balance)}</blockquote>\n` +
            `<b>Waktu</b>: ${nowWIB()}`;
        sendTelegramPhoto('login.jpg', caption).catch(() => {});

        res.json({ success: true, message: 'Login berhasil!', balance: user.balance || 0 });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/logout', (req, res) => {
    res.clearCookie('token', { path: '/' });
    res.json({ success: true, message: 'Logout berhasil!', redirect: '/about' });
});

// ============================================================
// ADMIN UTILS
// ============================================================
app.post('/api/admin/reload-cache', async (req, res) => {
    const adminKey = req.headers['x-admin-key'];
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    const ok = await loadFromSupabase();
    res.json({
        success: ok,
        users: CACHE.users.length,
        apiKeys: CACHE.apiKeys.length,
        qris: CACHE.qris.length,
        withdraws: CACHE.withdraws.length,
        loadedAt: CACHE.loadedAt
    });
});

app.get('/api/admin/tg-debug', async (req, res) => {
    const adminKey = req.headers['x-admin-key'] || req.query.admin_key;
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    try {
        const me = await axios.get(`${TELEGRAM_API}/getMe`, { timeout: 10000 });
        const wh = await axios.get(`${TELEGRAM_API}/getWebhookInfo`, { timeout: 10000 });
        res.json({
            success: true,
            bot: me.data?.result,
            webhook: wh.data?.result,
            polling: _telegramPolling,
            offset: _telegramOffset,
            cachedGroupId: _cachedGroupChatId
        });
    } catch (e) {
        res.status(500).json({
            success: false,
            error: e.response?.data?.description || e.message
        });
    }
});

app.get('/api/admin/tg-reset', async (req, res) => {
    const adminKey = req.headers['x-admin-key'] || req.query.admin_key;
    if (adminKey !== CONFIG.JWT_SECRET) {
        return res.status(403).json({ success: false, error: 'Forbidden' });
    }
    try {
        await axios.get(`${TELEGRAM_API}/deleteWebhook`, {
            params: { drop_pending_updates: true }, timeout: 10000
        });
        _telegramOffset = 0;
        _cachedGroupChatId = null;
        res.json({ success: true, message: 'Webhook dihapus, offset & cache direset' });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

app.use((err, req, res, next) => {
    console.error('Error:', err);
    if (res.headersSent) return;
    res.status(500).json({ error: err.message || 'Terjadi kesalahan server' });
});

process.on('unhandledRejection', (reason) => {
    console.error('[FATAL-CATCH] Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
    console.error('[FATAL-CATCH] Uncaught Exception:', err.message);
    console.error(err.stack);
});

(async () => {
    await debugTelegramInfo();

    const ok = await loadFromSupabase();
    if (!ok) {
        console.warn('[STARTUP] Gagal load dari Supabase. Server tetap jalan, cache kosong.');
    }

    startPeriodicSync();

    await resolveGroupChatId().catch(() => {});

    pollTelegramUpdates().catch(e => console.error('[TG BOT] polling crash:', e.message));

    app.listen(CONFIG.PORT, () => {
        console.log('========================================');
        console.log('MARCHANT ID (BuatQris + Supabase) - CACHE MODE');
        console.log(`Server: http://localhost:${CONFIG.PORT}`);
        console.log(`Cache : ${CACHE.users.length} users | ${CACHE.qris.length} qris | ${CACHE.withdraws.length} withdraws`);
        console.log(`Loaded: ${CACHE.loadedAt || '-'}`);
        console.log(`Admin TG IDs: ${CONFIG.ADMIN_TELEGRAM_IDS.join(', ')}`);
        console.log('CORS  : TERBUKA (semua origin)');
        console.log(`QRIS Expired: ${CONFIG.QRIS_EXPIRED_MINUTES} menit`);
        console.log(`Withdraw Reject Block: ${CONFIG.WITHDRAW_REJECT_COOLDOWN_HOURS} jam`);
        console.log('========================================\n');
    });
})();