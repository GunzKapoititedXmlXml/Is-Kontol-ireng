#!/usr/bin/env node
// ============================================================
// FAST TRADER — LAUNCHER
// ============================================================
// Cuma menjalankan:
//   1. setup.sh   (sekali di awal)
//   2. server.js  (jalan terus)
//
// TIDAK install ulang / TIDAK cek package / TIDAK apa-apa lagi.
// ============================================================

const { spawn, spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const ROOT = __dirname;
const SETUP_SH    = path.join(ROOT, 'setup.sh');
const SERVER_JS   = path.join(ROOT, 'index.js');
const MARKER_FILE = path.join(ROOT, '.setup-done');

const args = process.argv.slice(2);
const SKIP_SETUP  = args.includes('--skip-setup');
const SETUP_ONLY  = args.includes('--setup-only');
const FORCE_SETUP = args.includes('--force-setup');

// ============================================================
// LOGGER
// ============================================================
const C = {
    reset:  '\x1b[0m',
    bold:   '\x1b[1m',
    green:  '\x1b[32m',
    yellow: '\x1b[33m',
    red:    '\x1b[31m',
    cyan:   '\x1b[36m',
    gray:   '\x1b[90m'
};
const log     = (m) => console.log(m);
const logInfo = (m) => console.log(`${C.cyan}[INFO]${C.reset} ${m}`);
const logOk   = (m) => console.log(`${C.green}[ OK ]${C.reset} ${m}`);
const logWarn = (m) => console.log(`${C.yellow}[WARN]${C.reset} ${m}`);
const logErr  = (m) => console.error(`${C.red}[FAIL]${C.reset} ${m}`);

// ============================================================
// CEK FILE ADA ATAU TIDAK
// ============================================================
function fileExists(p) {
    try { return fs.existsSync(p); }
    catch { return false; }
}

// ============================================================
// PERLU SETUP?
// ============================================================
function shouldRunSetup() {
    if (SKIP_SETUP) {
        logWarn('Skip setup (flag --skip-setup)');
        return false;
    }
    if (FORCE_SETUP) {
        logInfo('Force setup (flag --force-setup)');
        return true;
    }
    // Default: cuma cek marker .setup-done
    // Kalau marker ada → skip setup
    // Kalau marker tidak ada → jalankan setup
    if (fileExists(MARKER_FILE)) {
        return false;
    }
    return true;
}

// ============================================================
// JALANKAN SETUP.SH (SINKRON — tunggu selesai dulu)
// ============================================================
function runSetup() {
    logInfo('Menjalankan setup.sh ...');

    if (!fileExists(SETUP_SH)) {
        logWarn('setup.sh tidak ada, skip.');
        return true;  // anggap sukses
    }

    const result = spawnSync('bash', [SETUP_SH], {
        stdio: 'inherit',
        cwd: ROOT
    });

    if (result.error) {
        logErr(`Gagal jalankan setup.sh: ${result.error.message}`);
        return false;
    }

    if (result.status !== 0) {
        logErr(`setup.sh exit code: ${result.status}`);
        return false;
    }

    // Buat marker supaya next start tidak setup lagi
    try {
        fs.writeFileSync(MARKER_FILE, new Date().toISOString());
    } catch (e) {
        logWarn(`Tidak bisa buat marker: ${e.message}`);
    }

    logOk('setup.sh selesai');
    return true;
}

// ============================================================
// JALANKAN SERVER.JS (NON-BLOCKING — jalan terus)
// ============================================================
function runServer() {
    logInfo('Menjalankan server.js ...');

    if (!fileExists(SERVER_JS)) {
        logErr('server.js tidak ditemukan!');
        process.exit(1);
    }

    const child = spawn('node', [SERVER_JS], {
        stdio: 'inherit',
        cwd: ROOT,
        env: process.env
    });

    // Forward signal ke child
    ['SIGINT', 'SIGTERM'].forEach(sig => {
        process.on(sig, () => {
            try { child.kill(sig); } catch {}
        });
    });

    child.on('exit', (code, signal) => {
        if (signal) {
            logWarn(`Server dihentikan (signal: ${signal})`);
            process.exit(0);
        }
        process.exit(code || 0);
    });

    child.on('error', (err) => {
        logErr(`Gagal jalankan server: ${err.message}`);
        process.exit(1);
    });
}

// ============================================================
// MAIN
// ============================================================
function main() {
    log('');
    log(`${C.bold}${C.cyan}====================================${C.reset}`);
    log(`${C.bold}${C.cyan}  FAST TRADER — LAUNCHER${C.reset}`);
    log(`${C.bold}${C.cyan}====================================${C.reset}`);
    log('');

    // ── Setup (kalau perlu) ──
    if (shouldRunSetup()) {
        const ok = runSetup();
        if (!ok) {
            logErr('Setup gagal. Stop.');
            process.exit(1);
        }
    } else {
        logOk('Setup sudah pernah dijalankan, skip');
    }

    // ── Stop kalau cuma setup ──
    if (SETUP_ONLY) {
        logOk('Selesai (--setup-only)');
        process.exit(0);
    }

    // ── Jalankan server ──
    runServer();
}

main();